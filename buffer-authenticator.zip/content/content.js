import{g as Y}from"../assets/brand-icons-DlF0MK7r.js";const Q="buffer-auth-inline-host",$="data-buffer-auth-detected";function _(e){if(e.maxLength!==1&&e.getAttribute("size")!=="1")return null;const r=e.form||e.closest("form")||e.parentElement;if(!r)return null;const i=Array.from(r.querySelectorAll("input")).filter(n=>(n.maxLength===1||n.getAttribute("size")==="1")&&(n.type==="tel"||n.type==="text"||n.type==="number"||n.type==="password"||n.inputMode==="numeric"));return i.length>=4&&i.length<=8&&i.includes(e)?i:null}function F(e){if(e.hasAttribute($)||e.type==="password"&&e.maxLength!==1||e.type==="hidden"||e.type==="checkbox"||e.type==="radio"||e.disabled||e.readOnly)return!1;const r=_(e);if(r)return r[0]===e?(r.slice(1).forEach(h=>h.setAttribute($,"cluster-sibling")),!0):!1;if((e.getAttribute("autocomplete")||"").toLowerCase()==="one-time-code")return!0;const n=(e.name||"").toLowerCase(),l=(e.id||"").toLowerCase(),a=(e.placeholder||"").toLowerCase(),s=(e.getAttribute("aria-label")||"").toLowerCase();if(["otp","2fa","mfa","totp","token","verification_code","security code","authenticator","two-factor","two_factor"].some(h=>n.includes(h)||l.includes(h)||a.includes(h)||s.includes(h)))return!0;const B=e.maxLength;return(B===6||B===8)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric")}function H(e){return e.length===6?`${e.slice(0,3)} ${e.slice(3)}`:e.length===8?`${e.slice(0,4)} ${e.slice(4)}`:e}function q(e){return e.replace(/[&<>"']/g,r=>{switch(r){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return r}})}function V(e,r){const i=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value")?.set;e.focus(),i?i.call(e,r):e.value=r;try{e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:r}))}catch{e.dispatchEvent(new Event("input",{bubbles:!0}))}e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{key:r,code:`Digit${r}`,bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keyup",{key:r,code:`Digit${r}`,bubbles:!0}))}function K(e,r){const i=r.replace(/\D/g,""),n=_(e)||(()=>{const l=e.form||e.closest("form")||e.parentElement;if(!l)return null;const a=Array.from(l.querySelectorAll("input")).filter(s=>(s.maxLength===1||s.getAttribute("size")==="1")&&(s.type==="tel"||s.type==="text"||s.type==="number"||s.type==="password"||s.inputMode==="numeric"));return a.length>=4&&a.length<=8?a:null})();if(n&&n.length>=i.length){n.forEach((a,s)=>{s<i.length&&V(a,i[s])}),n[Math.min(i.length-1,n.length-1)]?.focus();return}V(e,i)}function P(e){e.setAttribute($,"true");const r=window.getComputedStyle(e),i=parseFloat(r.paddingRight)||0;i<34&&(e.style.paddingRight=`${i+30}px`);const n=document.createElement("div");n.className=Q,n.style.position="fixed",n.style.top="0px",n.style.left="0px",n.style.width="0px",n.style.height="0px",n.style.zIndex="2147483646",n.style.pointerEvents="none";const l=n.attachShadow({mode:"open"});l.innerHTML=`
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      /* In-Field Shield App Icon Badge */
      .badge-btn {
        position: fixed;
        width: 24px;
        height: 24px;
        background: #111318;
        border: 1px solid rgba(168, 199, 250, 0.35);
        border-radius: 6px;
        color: #a8c7fa;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        pointer-events: auto;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.35);
        transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
        user-select: none;
        z-index: 2147483646;
      }
      .badge-btn:hover {
        background: #1e222a;
        border-color: #a8c7fa;
        color: #ffffff;
        transform: scale(1.08);
        box-shadow: 0 0 10px rgba(168, 199, 250, 0.45);
      }
      .badge-btn:active {
        transform: scale(0.96);
      }
      .badge-btn.active {
        background: #0842a0;
        border-color: #a8c7fa;
        color: #ffffff;
      }
      .shield-icon {
        width: 14px;
        height: 14px;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
      }

      /* Interactive 2FA Live Card Popover */
      .autofill-popover {
        position: fixed;
        width: 320px;
        background: #171a21;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 14px;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75), 0 4px 12px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(20px);
        color: #e2e2e9;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        padding: 12px;
        pointer-events: auto;
        z-index: 2147483647;
        opacity: 0;
        transform: translateY(-6px) scale(0.97);
        pointer-events: none;
        transition: all 0.18s cubic-bezier(0.2, 0, 0, 1);
      }
      .autofill-popover.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      /* Popover Header */
      .popover-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 10px;
      }
      .popover-title-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .popover-brand {
        font-size: 12px;
        font-weight: 700;
        color: #a8c7fa;
        letter-spacing: 0.2px;
      }
      .popover-domain {
        font-size: 10px;
        color: #9aa0a6;
        background: rgba(255, 255, 255, 0.06);
        padding: 2px 6px;
        border-radius: 4px;
        max-width: 140px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .btn-close-popover {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease;
      }
      .btn-close-popover:hover {
        color: #ffffff;
      }
      .popover-actions-row {
        display: flex;
        align-items: center;
        gap: 2px;
      }
      .btn-popover-lock {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease, background-color 0.15s ease;
      }
      .btn-popover-lock:hover {
        color: #ffb4ab;
        background: rgba(255, 255, 255, 0.06);
      }
      .btn-popover-lock.hidden {
        display: none;
      }

      /* Accounts List */
      .accounts-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 260px;
        overflow-y: auto;
      }
      .account-card {
        background: #20242e;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 10px 12px;
        transition: all 0.15s ease;
      }
      .account-card:hover {
        border-color: rgba(168, 199, 250, 0.35);
        background: #252a36;
      }

      .card-top {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
      }
      .card-avatar {
        width: 22px;
        height: 22px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        flex-shrink: 0;
        overflow: hidden;
      }
      .card-avatar svg {
        width: 14px;
        height: 14px;
      }
      .card-info {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .card-issuer {
        font-size: 12px;
        font-weight: 700;
        color: #ffffff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .card-account {
        font-size: 10.5px;
        color: #9aa0a6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .card-middle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      .card-code {
        font-family: "SFMono-Regular", Consolas, Menlo, monospace;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: 2px;
        color: #a8c7fa;
      }
      .btn-fill-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 6px;
        padding: 5px 12px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.15s ease;
      }
      .btn-fill-action:hover {
        background: #0c4fa0;
        color: #ffffff;
        transform: translateY(-1px);
      }
      .btn-fill-action:active {
        transform: translateY(0);
      }
      .btn-fill-action.filled {
        background: #137333 !important;
        color: #ffffff !important;
      }

      /* Progress Bar & Countdown Timer */
      .card-timer-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .timer-track {
        flex: 1;
        height: 4px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 9999px;
        overflow: hidden;
      }
      .timer-fill {
        height: 100%;
        background: #a8c7fa;
        border-radius: 9999px;
        transition: width 0.3s linear, background-color 0.3s ease;
      }
      .timer-fill.warning {
        background: #ffb951;
      }
      .timer-fill.danger {
        background: #ffb4ab;
      }
      .timer-label {
        font-size: 10px;
        font-weight: 600;
        color: #9aa0a6;
        min-width: 22px;
        text-align: right;
      }

      /* Locked or Empty State */
      .empty-box {
        text-align: center;
        padding: 16px 8px;
        color: #9aa0a6;
        font-size: 11.5px;
        line-height: 1.4;
      }
      .empty-box svg {
        margin-bottom: 6px;
        color: #a8c7fa;
      }
      .empty-box .empty-sub {
        font-size: 10px;
        color: #6c727d;
        margin-top: 4px;
      }

      /* In-Popover Unlock Form */
      .unlock-panel {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding: 2px;
      }
      .unlock-header {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .unlock-icon-badge {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: rgba(168, 199, 250, 0.12);
        border: 1px solid rgba(168, 199, 250, 0.25);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #a8c7fa;
        flex-shrink: 0;
      }
      .unlock-text {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .unlock-title {
        font-size: 13px;
        font-weight: 700;
        color: #ffffff;
        line-height: 1.2;
        margin-bottom: 2px;
      }
      .unlock-desc {
        font-size: 11px;
        color: #9aa0a6;
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .unlock-desc strong {
        color: #a8c7fa;
      }
      .unlock-form {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 2px;
      }
      .unlock-input-row {
        position: relative;
        display: flex;
        align-items: center;
        width: 100%;
      }
      .unlock-password-input {
        width: 100%;
        background: #0e1015;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 8px;
        padding: 8px 34px 8px 10px;
        font-size: 12.5px;
        color: #ffffff;
        outline: none;
        font-family: inherit;
        box-sizing: border-box;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .unlock-password-input:focus {
        border-color: #a8c7fa;
        box-shadow: 0 0 0 2px rgba(168, 199, 250, 0.25);
      }
      .unlock-password-input::placeholder {
        color: #6c727d;
      }
      .btn-toggle-eye {
        position: absolute;
        right: 6px;
        background: transparent;
        border: none;
        color: #80868b;
        cursor: pointer;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: color 0.15s ease;
      }
      .btn-toggle-eye:hover {
        color: #ffffff;
      }
      .unlock-error-msg {
        font-size: 11px;
        color: #ffb4ab;
        background: rgba(147, 0, 10, 0.25);
        border: 1px solid rgba(255, 180, 171, 0.25);
        border-radius: 6px;
        padding: 6px 8px;
        line-height: 1.3;
        animation: shake 0.25s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
      }
      .unlock-error-msg.hidden {
        display: none;
      }
      @keyframes shake {
        10%, 90% { transform: translate3d(-1px, 0, 0); }
        20%, 80% { transform: translate3d(2px, 0, 0); }
        30%, 50%, 70% { transform: translate3d(-3px, 0, 0); }
        40%, 60% { transform: translate3d(3px, 0, 0); }
      }
      .btn-unlock-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 8px;
        padding: 8px 14px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        width: 100%;
        transition: all 0.15s ease;
      }
      .btn-unlock-action:hover:not(:disabled) {
        background: #0b57d0;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(11, 87, 208, 0.4);
      }
      .btn-unlock-action:active:not(:disabled) {
        transform: scale(0.98);
      }
      .btn-unlock-action:disabled {
        opacity: 0.65;
        cursor: not-allowed;
      }
      .spin-icon {
        animation: spin 1s linear infinite;
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    </style>

    <button type="button" class="badge-btn" id="badge-trigger" title="Buffer Authenticator (Click to view live 2FA code)">
      <svg class="shield-icon" viewBox="0 0 24 24">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    </button>

    <div class="autofill-popover" id="popover-panel">
      <div class="popover-header">
        <div class="popover-title-row">
          <svg class="shield-icon" style="width: 13px; height: 13px; color: #a8c7fa;" viewBox="0 0 24 24">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span class="popover-brand">Buffer Authenticator</span>
          <span class="popover-domain" id="domain-label"></span>
        </div>
        <div class="popover-actions-row">
          <button type="button" class="btn-popover-lock hidden" id="btn-popover-lock" title="Lock Vault">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </button>
          <button type="button" class="btn-close-popover" id="btn-close" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="accounts-list" id="accounts-list-container">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `,document.body.appendChild(n);const a=l.getElementById("badge-trigger"),s=l.getElementById("popover-panel"),C=l.getElementById("domain-label"),d=l.getElementById("accounts-list-container"),B=l.getElementById("btn-close"),h=l.getElementById("btn-popover-lock");C.textContent=window.location.hostname;let b=[],m=null,y=!1,x=!1,T=!0;function M(){if(!document.contains(e)){n.remove();return}const o=e.getBoundingClientRect(),t=window.getComputedStyle(e);if(o.width===0||o.height===0||t.display==="none"||t.visibility==="hidden"){a.style.display="none",y&&A();return}a.style.display="flex";const c=24,f=Math.round(o.top+(o.height-c)/2),p=Math.round(o.right-c-6);a.style.top=`${f}px`,a.style.left=`${p}px`,y&&E(o)}function E(o){const t=o||e.getBoundingClientRect(),c=320,f=s.offsetHeight||160,p=Math.max(8,Math.min(t.left,window.innerWidth-c-12));window.innerHeight-t.bottom>=f+10||t.top<f+10?s.style.top=`${Math.round(t.bottom+6)}px`:s.style.top=`${Math.round(t.top-f-6)}px`,s.style.left=`${Math.round(p)}px`}function O(){m&&clearInterval(m),!(x||!T||b.length===0)&&(m=setInterval(async()=>{let o=!1;b.forEach(t=>{t.secondsRemaining-=1,t.secondsRemaining<=0&&(o=!0)}),o?(await I(),S()):U()},1e3))}function S(){if(d.innerHTML="",!T){h.classList.add("hidden"),d.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <p>Vault is not set up</p>
          <p class="empty-sub">Open Buffer Authenticator from your toolbar to set up your master password.</p>
        </div>
      `;return}if(x){h.classList.add("hidden"),d.innerHTML=`
        <div class="unlock-panel">
          <div class="unlock-header">
            <div class="unlock-icon-badge">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            <div class="unlock-text">
              <div class="unlock-title">Vault is Locked</div>
              <div class="unlock-desc">Enter password to unlock 2FA codes</div>
            </div>
          </div>

          <form id="popover-unlock-form" class="unlock-form">
            <div class="unlock-input-row">
              <input
                type="password"
                id="popover-password-input"
                class="unlock-password-input"
                placeholder="Enter master password"
                autocomplete="current-password"
                required
              />
              <button type="button" id="popover-btn-toggle-eye" class="btn-toggle-eye" title="Show/Hide password">
                <svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
              </button>
            </div>

            <div id="popover-unlock-error" class="unlock-error-msg hidden"></div>

            <button type="submit" id="popover-btn-unlock" class="btn-unlock-action">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            </button>
          </form>
        </div>
      `;const o=d.querySelector("#popover-btn-toggle-eye"),t=d.querySelector("#popover-password-input"),c=d.querySelector("#popover-unlock-error"),f=d.querySelector("#popover-unlock-form"),p=d.querySelector("#popover-btn-unlock");let g=!1;o&&t&&o.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),g=!g,t.type=g?"text":"password",o.innerHTML=g?`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>`:`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>`}),t&&(t.addEventListener("keydown",u=>u.stopPropagation()),t.addEventListener("keyup",u=>u.stopPropagation()),t.addEventListener("keypress",u=>u.stopPropagation()),setTimeout(()=>{y&&x&&t.focus()},50)),f&&t&&c&&p&&f.addEventListener("submit",async u=>{u.preventDefault(),u.stopPropagation();const v=t.value;if(v){c.classList.add("hidden"),c.textContent="",p.disabled=!0,p.innerHTML=`
            <svg class="spin-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25"/>
              <path d="M12 2a10 10 0 0 1 10 10"/>
            </svg>
            <span>Unlocking...</span>
          `;try{const w=await chrome.runtime.sendMessage({type:"UNLOCK_VAULT",payload:{password:v}});w&&w.success?(x=!1,await I(),S(),E(),O()):(p.disabled=!1,p.innerHTML=`
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
                </svg>
                <span>Unlock Vault</span>
              `,c.textContent=w?.error||"Incorrect master password",c.classList.remove("hidden"),t.focus(),t.select(),E())}catch(w){p.disabled=!1,p.innerHTML=`
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            `,c.textContent=w?.message||"Failed to unlock vault",c.classList.remove("hidden"),t.focus(),E()}}});return}if(h.classList.remove("hidden"),b.length===0){d.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <p>No 2FA account found for <strong>${q(window.location.hostname)}</strong></p>
          <p class="empty-sub">Add this account in Buffer Authenticator popup</p>
        </div>
      `;return}b.forEach(o=>{const t=document.createElement("div");t.className="account-card",t.setAttribute("data-id",o.id);const c=Y(o.issuer||o.account),f=o.period||30,p=Math.max(0,o.secondsRemaining),g=Math.max(0,Math.min(100,p/f*100));let u="";p<=5?u="danger":p<=10&&(u="warning"),t.innerHTML=`
        <div class="card-top">
          <div class="card-avatar" style="background: ${c.bg}; color: ${c.color};">
            ${c.svg?c.svg:c.label}
          </div>
          <div class="card-info">
            <span class="card-issuer" title="${o.issuer||"Account"}">${o.issuer||"Account"}</span>
            <span class="card-account" title="${o.account}">${o.account}</span>
          </div>
        </div>

        <div class="card-middle">
          <span class="card-code" data-code="${o.code}">${H(o.code)}</span>
          <button type="button" class="btn-fill-action" data-fill="${o.code}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span>Fill Code</span>
          </button>
        </div>

        <div class="card-timer-row">
          <div class="timer-track">
            <div class="timer-fill ${u}" style="width: ${g}%;"></div>
          </div>
          <span class="timer-label">${p}s</span>
        </div>
      `;const v=t.querySelector(".btn-fill-action"),w=z=>{z.stopPropagation(),K(e,o.code),v.classList.add("filled"),v.innerHTML=`
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Filled!</span>
        `,setTimeout(()=>{A()},400)};v.addEventListener("click",w),t.addEventListener("click",z=>{z.target.closest(".btn-fill-action")||w(z)}),d.appendChild(t)})}function U(){b.forEach(o=>{const t=d.querySelector(`.account-card[data-id="${o.id}"]`);if(!t)return;const c=o.period||30,f=Math.max(0,o.secondsRemaining),p=Math.max(0,Math.min(100,f/c*100)),g=t.querySelector(".timer-fill"),u=t.querySelector(".timer-label"),v=t.querySelector(".card-code");g&&(g.style.width=`${p}%`,g.className="timer-fill",f<=5?g.classList.add("danger"):f<=10&&g.classList.add("warning")),u&&(u.textContent=`${f}s`),v&&(v.textContent=H(o.code))})}async function I(){try{const o={type:"GET_CODE_FOR_DOMAIN",payload:{domain:window.location.hostname}},t=await chrome.runtime.sendMessage(o);if(t&&t.success&&t.data)return x=!!t.data.isLocked,T=t.data.isInitialized!==!1,t.data.matched&&t.data.matched.length>0?b=t.data.matched:t.data.all&&t.data.all.length>0?b=t.data.all:b=[],!0;try{const c=await chrome.runtime.sendMessage({type:"GET_STATUS"});c&&c.success&&c.data&&(x=!!c.data.isLocked,T=!!c.data.isInitialized)}catch{x=!1}return b=[],!1}catch{return b=[],x=!1,!1}}async function j(){y=!0,a.classList.add("active"),d.innerHTML=`
      <div class="empty-box">
        <p>Loading live 2FA code...</p>
      </div>
    `,s.classList.add("open"),E(),await I(),S(),E(),O()}function A(){y=!1,a.classList.remove("active"),s.classList.remove("open"),m&&(clearInterval(m),m=null)}a.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),y?A():j()}),B.addEventListener("click",o=>{o.stopPropagation(),A()}),h.addEventListener("click",async o=>{o.stopPropagation();try{await chrome.runtime.sendMessage({type:"LOCK_VAULT"})}catch{}x=!0,b=[],m&&(clearInterval(m),m=null),S(),E()}),s.addEventListener("click",o=>{o.stopPropagation()}),document.addEventListener("click",o=>{if(!y)return;const t=o.target;t!==e&&!n.contains(t)&&A()}),document.addEventListener("keydown",o=>{o.key==="Escape"&&y&&A()}),window.addEventListener("scroll",M,{passive:!0,capture:!0}),window.addEventListener("resize",M,{passive:!0}),new ResizeObserver(()=>{M()}).observe(e),e.addEventListener("focus",M),e.addEventListener("input",M),M()}const G='input[autocomplete="one-time-code"], input[name*="otp" i], input[name*="2fa" i], input[name*="mfa" i], input[name*="code" i], input[id*="otp" i], input[id*="2fa" i], input[id*="code" i], input[placeholder*="code" i], input[type="tel"], input[type="number"]';function R(e=document){if(e.querySelectorAll(G).forEach(i=>{F(i)&&P(i)}),e===document){const i=document.querySelectorAll("input");i.length<60&&i.forEach(n=>{F(n)&&P(n)})}}R();const D=new MutationObserver(e=>{for(let r=0;r<e.length;r++){const i=e[r].addedNodes;for(let n=0;n<i.length;n++){const l=i[n];if(l.nodeType===1){const a=l;a.tagName==="INPUT"&&F(a)?P(a):a.firstElementChild&&R(a)}}}});function N(){const e=document.body||document.documentElement;e&&D.observe(e,{childList:!0,subtree:!0})}N();document.addEventListener("visibilitychange",()=>{document.hidden?D.disconnect():(R(),N())});let L=null;document.addEventListener("contextmenu",e=>{L=e.target},!0);function k(e,r="success"){let i=document.getElementById("buffer-auth-toast-container");i||(i=document.createElement("div"),i.id="buffer-auth-toast-container",i.style.cssText=`
      position: fixed;
      top: 24px;
      right: 24px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `,document.body.appendChild(i));const n=document.createElement("div"),l=r==="error"?"#2A1818":r==="warning"?"#2A2214":"#141E28",a=r==="error"?"#FF6B6B":r==="warning"?"#FFB951":"#A8C7FA",s=r==="error"?"#FFDADA":r==="warning"?"#FFF2D6":"#E2E2E9",C=r==="error"?"✕":r==="warning"?"⚠":"✓";n.style.cssText=`
    display: flex;
    align-items: center;
    gap: 12px;
    background: ${l};
    border: 1px solid ${a};
    color: ${s};
    padding: 12px 18px;
    border-radius: 16px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.55), inset 1px 1px 2px rgba(255, 255, 255, 0.12);
    font-size: 13.5px;
    font-weight: 600;
    pointer-events: auto;
    transform: translateY(-10px);
    opacity: 0;
    transition: all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  `,n.innerHTML=`
    <span style="font-size: 16px; color: ${a}; font-weight: 800;">${C}</span>
    <span>${q(e)}</span>
  `,i.appendChild(n),requestAnimationFrame(()=>{n.style.transform="translateY(0)",n.style.opacity="1"}),setTimeout(()=>{n.style.transform="translateY(-10px)",n.style.opacity="0",setTimeout(()=>n.remove(),300)},4200)}async function W(e){k("Scanning QR code with Buffer Authenticator...","warning");try{if(!("BarcodeDetector"in window)){k("BarcodeDetector API is unavailable in this browser","error");return}let r=null;if(L instanceof HTMLImageElement&&(L.currentSrc||L.src)||L instanceof HTMLCanvasElement?r=L:e&&(r=await new Promise((s,C)=>{const d=new Image;d.crossOrigin="anonymous",d.onload=()=>s(d),d.onerror=()=>C(new Error("Failed to load image from page URL")),d.src=e})),!r){k("Could not find image element to scan","error");return}const n=await new window.BarcodeDetector({formats:["qr_code"]}).detect(r);if(!n||n.length===0){k("No QR code detected in the selected image","error");return}const l=n[0].rawValue,a=await chrome.runtime.sendMessage({type:"IMPORT_VAULT",payload:{data:l}});if(a.success&&a.data)k(`✓ Added ${a.data.importedCount} account(s) to Buffer Authenticator!`,"success");else{const s=a.error||"Failed to import account";s.toLowerCase().includes("locked")?k("Buffer Authenticator is locked! Please unlock your vault first.","warning"):k(s,"error")}}catch(r){k(r.message||"Error scanning QR code","error")}}chrome.runtime.onMessage.addListener((e,r,i)=>{e.type==="CONTEXT_MENU_SCAN_QR"&&(W(e.srcUrl),i({received:!0}))});
