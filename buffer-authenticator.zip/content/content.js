(function(){"use strict";function q(e,s){const o=e&&e.trim()||s&&s.trim()||"",t=`${e||""} ${s||""}`.toLowerCase().trim().replace(/[-_.]/g," ");if(t.includes("google")||t.includes("gmail"))return{bg:"#1a2332",color:"#4285F4",label:"G",svg:'<svg viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/></svg>'};if(t.includes("github"))return{bg:"#24292e",color:"#ffffff",label:"GH",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/></svg>'};if(t.includes("instagram")||t.includes("insta"))return{bg:"#331326",color:"#E1306C",label:"IG",svg:'<svg viewBox="0 0 24 24" fill="none" stroke="#E1306C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5.5" ry="5.5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.8" fill="#E1306C" stroke="none"/></svg>'};if(t.includes("snapchat")||t.includes("snap chat"))return{bg:"#333008",color:"#FFFC00",label:"SC",svg:'<svg viewBox="0 0 24 24" fill="#FFFC00"><path d="M12.001 2.5c-3.3 0-5.5 2.45-5.5 5.73 0 1.08.22 2.37.52 3.13-.57.22-1.32.55-1.67 1.1-.37.6-.25 1.38.29 1.66.47.24 1.23.08 1.82-.12.2.96.85 2.2 1.99 2.9-.57.24-1.28.46-1.75.92-.51.51-.38 1.35.08 1.57 1.15.56 3.18.28 4.2-.3 1 .58 3.04.86 4.19.3.46-.22.59-1.06.08-1.57-.46-.46-1.17-.68-1.74-.92 1.13-.7 1.78-1.94 1.99-2.9.59.2 1.35.36 1.82.12.54-.28.66-1.06.29-1.65-.36-.56-1.11-.88-1.68-1.11.3-.75.53-2.05.53-3.13 0-3.28-2.16-5.73-5.48-5.73z"/></svg>'};if(t.includes("teamviewer")||t.includes("team viewer"))return{bg:"#0a2444",color:"#0E70EB",label:"TV",svg:'<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9.5" fill="#0E70EB"/><path d="M7 12h10 M14 9l3 3-3 3 M10 9l-3 3 3 3" stroke="#FFFFFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'};if(t.includes("tiktok")||t.includes("tik tok"))return{bg:"#161920",color:"#25F4EE",label:"TT",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.589 6.686a4.793 4.793 0 0 1-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 1 1-2.896-2.895c.386 0 .753.076 1.09.213V9.453A6.335 6.335 0 0 0 9.07 9.17 6.34 6.34 0 1 0 15.41 15.51V8.65a8.21 8.21 0 0 0 4.179 1.135V6.686z"/></svg>'};if(t.includes("whatsapp")||t.includes("whats app"))return{bg:"#102d1e",color:"#25D366",label:"WA",svg:'<svg viewBox="0 0 24 24" fill="#25D366"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.39-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.196 8.196 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24m4.52 11.59c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.13-1.06-.39-2.02-1.24-.74-.66-1.24-1.48-1.39-1.73-.14-.25-.02-.39.11-.51.11-.11.25-.29.37-.43.13-.15.17-.25.25-.42.08-.17.04-.32-.02-.45-.06-.13-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.17 0-.45.06-.68.32-.23.25-.89.87-.89 2.12s.91 2.46 1.04 2.63c.13.17 1.79 2.73 4.33 3.83.61.26 1.08.42 1.45.54.61.19 1.16.17 1.6-.08.49-.28 1.47-.6 1.68-1.18.21-.58.21-1.07.15-1.18-.06-.11-.23-.17-.48-.3z"/></svg>'};if(t.includes("discord"))return{bg:"#2c2f48",color:"#5865F2",label:"DC",svg:'<svg viewBox="0 0 24 24" fill="#5865F2"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>'};if(t.includes("microsoft")||t.includes("outlook")||t.includes("office365")||t.includes("office 365")||t.includes("azure"))return{bg:"#182538",color:"#00a4ef",label:"MS",svg:'<svg viewBox="0 0 24 24"><path fill="#f25022" d="M2 2h9v9H2z"/><path fill="#7fba00" d="M13 2h9v9h-9z"/><path fill="#00a4ef" d="M2 13h9v9H2z"/><path fill="#ffb900" d="M13 13h9v9h-9z"/></svg>'};if(t.includes("amazon")||t.includes("aws"))return{bg:"#2d2218",color:"#FF9900",label:"AWS",svg:'<svg viewBox="0 0 24 24" fill="#FF9900"><path d="M13.91 10.94c0-.98-.67-1.46-1.78-1.46-.86 0-1.57.34-2.14.93l-1.07-1.3c.88-.91 2.01-1.38 3.39-1.38 2.21 0 3.53 1.15 3.53 3.16v4.61h-1.83v-.93c-.66.7-1.55 1.08-2.58 1.08-1.78 0-2.93-1.08-2.93-2.61 0-1.71 1.33-2.58 3.56-2.73l1.85-.12v-.25zm0 1.48l-1.55.1c-1.37.09-2.09.52-2.09 1.38 0 .76.62 1.25 1.57 1.25.99 0 1.76-.51 2.07-1.32v-1.41zM21.57 18.25c-5.74 3.73-13.68 3.73-19.14 0-.44-.3-.08-.75.38-.46 4.96 3.16 12.02 3.16 18.38 0 .5-.25.82.16.38.46zm-2.03-1.72c-.41-.53-1.36-.26-1.99-.12-.22.05-.28-.15-.1-.28 1.17-.83 2.5-1.08 2.81-.68.32.41-.12 1.83-1.12 2.82-.16.16-.32.07-.25-.13.2-.62.83-1.45.65-1.61z"/></svg>'};if(t.includes("steam")||t.includes("valve"))return{bg:"#1b2838",color:"#66c0f4",label:"STM",svg:'<svg viewBox="0 0 24 24" fill="#66c0f4"><path d="M12 2a10 10 0 0 0-9.98 9.25l5.65 2.33a3.5 3.5 0 0 1 2.33-.93c.27 0 .53.03.78.1l2.58-3.75a4.5 4.5 0 1 1 4.64 6.88l-3.75 2.58a3.5 3.5 0 0 1-5.69 1.78l-5.32-2.2A10 10 0 1 0 12 2zm6 8.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm-9.5 7a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/></svg>'};if(t.includes("apple")||t.includes("icloud"))return{bg:"#252528",color:"#ffffff",label:"APL",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.38c.62-.75 1.04-1.8 1.01-2.88-.93.04-2.03.62-2.67 1.38-.56.65-1.06 1.71-.93 2.76 1.03.08 2.07-.53 2.59-1.26z"/></svg>'};if(t.includes("reddit"))return{bg:"#331a14",color:"#FF4500",label:"RD",svg:'<svg viewBox="0 0 24 24" fill="#FF4500"><path d="M12 2C6.48 2 2 6.48 2 12c0 5.52 4.48 10 10 10s10-4.48 10-10c0-5.52-4.48-10-10-10zm5.9 11.8c.1.2.1.4.1.6 0 2.5-3.1 4.5-6.9 4.5s-6.9-2-6.9-4.5c0-.2 0-.4.1-.6-.5-.4-.8-1-.8-1.6 0-1.3 1.1-2.4 2.4-2.4.6 0 1.2.3 1.6.7 1.1-.7 2.5-1.2 4.1-1.3l.8-3.7 2.6.6c.1-.5.6-.9 1.2-.9.7 0 1.3.6 1.3 1.3s-.6 1.3-1.3 1.3c-.6 0-1.1-.4-1.3-.9l-2.1-.5-.6 3c1.6.1 3 .6 4.1 1.3.4-.4 1-.7 1.6-.7 1.3 0 2.4 1.1 2.4 2.4-.1.7-.4 1.2-.9 1.6zm-8.4-1.3c-.6 0-1.1.5-1.1 1.1s.5 1.1 1.1 1.1 1.1-.5 1.1-1.1-.5-1.1-1.1-1.1zm5 0c-.6 0-1.1.5-1.1 1.1s.5 1.1 1.1 1.1 1.1-.5 1.1-1.1-.5-1.1-1.1-1.1zm-4.9 3.9c-.1-.1-.1-.3 0-.4.1-.1.3-.1.4 0 .8.8 2.2.8 3 0 .1-.1.3-.1.4 0 .1.1.1.3 0 .4-1 1-2.8 1-3.8 0z"/></svg>'};if(t.includes("twitter")||t.includes("x.com")||t.split(" ").includes("x"))return{bg:"#1b222d",color:"#ffffff",label:"X",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'};if(t.includes("facebook")||t.includes("meta"))return{bg:"#0c2e59",color:"#1877f2",label:"FB",svg:'<svg viewBox="0 0 24 24" fill="#1877f2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>'};if(t.includes("binance")||t.includes("bnb"))return{bg:"#2b2308",color:"#F0B90B",label:"BNB",svg:'<svg viewBox="0 0 24 24" fill="#F0B90B"><path d="M16.624 13.92l2.715 2.715-7.34 7.34-7.339-7.34 2.715-2.715 4.624 4.624 4.626-4.624zm-4.625-10.92l7.34 7.34-2.715 2.715-4.625-4.624-4.625 4.624-2.715-2.715 7.34-7.34zm8.965 8.965l2.716 2.715-2.716 2.715-2.715-2.715 2.715-2.715zm-17.93 0l2.715 2.715-2.715 2.715-2.715-2.715 2.715-2.715zm8.965.986l1.729 1.729-1.729 1.729-1.729-1.729 1.729-1.729z"/></svg>'};if(t.includes("coinbase"))return{bg:"#0b2247",color:"#0052FF",label:"CB",svg:'<svg viewBox="0 0 24 24" fill="#0052FF"><circle cx="12" cy="12" r="10"/><rect x="8.5" y="8.5" width="7" height="7" rx="1.5" fill="#FFFFFF"/></svg>'};if(t.includes("cloudflare"))return{bg:"#332014",color:"#F38020",label:"CF",svg:'<svg viewBox="0 0 24 24" fill="#F38020"><path d="M18.3 12.2c-.3-1.8-1.7-3.1-3.5-3.3-.5-.1-1 0-1.4.2C12.7 7.7 11.1 7 9.4 7.3c-2 .3-3.6 1.9-3.9 3.9-.7.2-1.3.6-1.7 1.2-.6.8-.7 1.9-.3 2.8.4.9 1.2 1.5 2.2 1.6h12.5c1.4-.1 2.5-1.2 2.6-2.6 0-1-.5-2-1.4-2.5-.3.2-.8.4-1.1.5zm-5.7 4.2H5.7c-.6 0-1.1-.3-1.4-.7-.2-.5-.2-1.1.1-1.5.3-.4.8-.7 1.3-.7h.6v-.6c0-1.8 1.4-3.2 3.2-3.2 1.1 0 2.1.6 2.7 1.5l.3.5.6-.2c.4-.1.8-.2 1.2-.2 1.5 0 2.8 1.1 3 2.6l.1.6h.6c.7 0 1.3.6 1.3 1.3s-.6 1.3-1.3 1.3h-6.2z"/></svg>'};if(t.includes("twitch"))return{bg:"#271b38",color:"#9146FF",label:"TW",svg:'<svg viewBox="0 0 24 24" fill="#9146FF"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0h1.714v5.143h-1.714zM2.5 2L1 6.286v13.714h5.143V22l3.428-2h3.429L22 11V2H2.5zm16.714 8.143l-2.571 2.571h-3.429l-2.143 2.143v-2.143H6.786V4.571h12.428v5.572z"/></svg>'};if(t.includes("openai")||t.includes("chatgpt"))return{bg:"#123028",color:"#10A37F",label:"AI",svg:'<svg viewBox="0 0 24 24" fill="#10A37F"><path d="M22.28 10.57a5.57 5.57 0 0 0-.47-4.48 5.67 5.67 0 0 0-4.73-2.82 5.56 5.56 0 0 0-4.08-1.83 5.65 5.65 0 0 0-5.37 3.86 5.58 5.58 0 0 0-3.62 2.63 5.67 5.67 0 0 0 .69 6.28 5.57 5.57 0 0 0 .47 4.48 5.67 5.67 0 0 0 4.73 2.82 5.56 5.56 0 0 0 4.08 1.83 5.65 5.65 0 0 0 5.37-3.86 5.58 5.58 0 0 0 3.62-2.63 5.67 5.67 0 0 0-.69-6.28zm-8.8 9.94a4.13 4.13 0 0 1-2.55-.89l.13-.07 4.22-2.44a.79.79 0 0 0 .39-.68v-5.94l1.78 1.03v5.44a4.16 4.16 0 0 1-4.01 3.55zM4.68 17.5a4.13 4.13 0 0 1-.5-2.65l.13.08 4.22 2.44a.77.77 0 0 0 .78 0l5.14-2.97v2.06l-4.71 2.72a4.16 4.16 0 0 1-5.06-1.68zm-1.1-7.94a4.15 4.15 0 0 1 2.05-1.76v5.03a.78.78 0 0 0 .39.68l5.14 2.97-1.78 1.03-4.71-2.72a4.16 4.16 0 0 1-1.09-5.23zm13.9 1.4l-5.14-2.97 1.78-1.03 4.71 2.72a4.16 4.16 0 0 1 1.09 5.23 4.15 4.15 0 0 1-2.05 1.76v-5.03a.78.78 0 0 0-.39-.68zm2.4 4.54l-.13-.08-4.22-2.44a.77.77 0 0 0-.78 0l-5.14 2.97v-2.06l4.71-2.72a4.16 4.16 0 0 1 5.06 1.68 4.13 4.13 0 0 1 .5 2.65zM10.5 12l2.36-1.36 2.36 1.36v2.73L12.86 16.1 10.5 14.73V12z"/></svg>'};if(t.includes("spotify"))return{bg:"#12301c",color:"#1DB954",label:"SPF",svg:'<svg viewBox="0 0 24 24" fill="#1DB954"><path d="M12 2C6.477 2 2 6.477 2 12c0 5.524 4.477 10 10 10s10-4.476 10-10c0-5.523-4.477-10-10-10zm4.586 14.424a.623.623 0 0 1-.857.207c-2.348-1.435-5.304-1.76-8.785-.964a.623.623 0 0 1-.277-1.215c3.807-.87 7.076-.496 9.712 1.115a.624.624 0 0 1 .207.856zm1.224-2.722a.78.78 0 0 1-1.073.257c-2.687-1.652-6.785-2.131-9.965-1.166a.78.78 0 0 1-.458-1.491c3.633-1.103 8.147-.568 11.239 1.328a.78.78 0 0 1 .257 1.072zm.105-2.835C14.692 8.95 9.375 8.775 6.297 9.71a.936.936 0 1 1-.55-1.791c3.535-1.073 9.404-.866 13.115 1.338a.936.936 0 0 1-.947 1.61z"/></svg>'};if(t.includes("paypal")||t.includes("pay pal"))return{bg:"#0e2340",color:"#0079C1",label:"PP",svg:'<svg viewBox="0 0 24 24" fill="#0079C1"><path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 2.894a.96.96 0 0 1 .947-.8h7.026c2.81 0 4.887.697 5.86 1.965.94 1.225.967 2.875.08 4.908-.946 2.167-2.686 3.7-5.176 4.557-1.173.404-2.528.608-4.032.608H7.95a.96.96 0 0 0-.948.803l-1.115 7.06a.64.64 0 0 0 .633.74l.556-.398z"/></svg>'};if(t.includes("gitlab"))return{bg:"#331c12",color:"#FC6D26",label:"GL",svg:'<svg viewBox="0 0 24 24"><path fill="#E24329" d="m12 21.42-3.87-11.9H15.87L12 21.42z"/><path fill="#FC6D26" d="M12 21.42 8.13 9.52H1.72L12 21.42z"/><path fill="#FCA326" d="M1.72 9.52l-.95 2.93c-.2.62.02 1.3.54 1.68L12 21.42 1.72 9.52z"/><path fill="#E24329" d="M1.72 9.52h6.41L5.68 1.96c-.24-.73-1.27-.73-1.5 0L1.72 9.52z"/><path fill="#FC6D26" d="M12 21.42l3.87-11.9h6.41L12 21.42z"/><path fill="#FCA326" d="m22.28 9.52.95 2.93c.2.62-.02 1.3-.54 1.68L12 21.42l10.28-11.9z"/><path fill="#E24329" d="M22.28 9.52h-6.41l2.45-7.56c.24-.73 1.27-.73 1.5 0l2.46 7.56z"/></svg>'};if(t.includes("dropbox"))return{bg:"#10243d",color:"#0061FF",label:"DBX",svg:'<svg viewBox="0 0 24 24" fill="#0061FF"><path d="M6.035 2L0 6.023l6.035 4.024 6.036-4.024L6.035 2zm11.93 0l-6.036 4.023 6.036 4.024 6.035-4.024L17.965 2zM0 14.07l6.035 4.024 6.036-4.024-6.036-4.023L0 14.07zm17.965-4.023l-6.036 4.023 6.036 4.024 6.035-4.024-6.035-4.023zM6.035 19.467L12 15.49l5.965 3.977L12 23.444l-5.965-3.977z"/></svg>'};if(t.includes("proton"))return{bg:"#211833",color:"#6D4AFF",label:"PR",svg:'<svg viewBox="0 0 24 24" fill="#6D4AFF"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 14.5h-2v-5h2v5zm0-7h-2V7.5h2V9.5z"/></svg>'};if(t.includes("notion"))return{bg:"#252525",color:"#ffffff",label:"N",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.459 4.208c.746.606 1.026.56 2.428.466l13.215-.793c.28 0 .047-.28-.093-.373L17.818 1.97c-.56-.42-1.307-.7-2.053-.653L2.733 2.296c-.466.047-.56.327-.373.513l2.099 1.399zm-.793 4.293v12.316c0 .793.42 1.073 1.26 1.026l14.288-.84c.84-.046.933-.56.933-1.12V7.754c0-.606-.233-.933-.793-.886l-14.894.886c-.56.046-.794.373-.794.747zm13.122.933c.093.42 0 .84-.42.886l-.793.14c-.373.047-.56-.14-.653-.513l-1.447-4.293h-1.54l-1.726 4.386c-.093.28-.28.42-.653.373l-.793-.14c-.42-.046-.513-.42-.373-.84l2.193-5.226c.14-.373.466-.606.886-.606h.98c.42 0 .746.233.886.606l2.453 5.227z"/></svg>'};if(t.includes("linkedin"))return{bg:"#0a2540",color:"#0A66C2",label:"IN",svg:'<svg viewBox="0 0 24 24" fill="#0A66C2"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9h2.79v8.37H6.46v-8.37M7.86 6.54a1.63 1.63 0 0 0-1.63 1.63c0 .9.73 1.63 1.63 1.63.9 0 1.63-.73 1.63-1.63 0-.9-.73-1.63-1.63-1.63z"/></svg>'};if(t.includes("telegram"))return{bg:"#142c40",color:"#24A1DE",label:"TG",svg:'<svg viewBox="0 0 24 24" fill="#24A1DE"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg>'};if(t.includes("bitwarden"))return{bg:"#0f2240",color:"#175DDC",label:"BW",svg:'<svg viewBox="0 0 24 24" fill="#175DDC"><path d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm0 3.3c2.6 0 4.7 2.1 4.7 4.7 0 2.2-1.5 4.1-3.6 4.6v3.2h-2.2v-3.2c-2.1-.5-3.6-2.4-3.6-4.6 0-2.6 2.1-4.7 4.7-4.7z"/></svg>'};if(t.includes("1password")||t.includes("onepassword"))return{bg:"#0b243d",color:"#0A85EA",label:"1P",svg:'<svg viewBox="0 0 24 24" fill="#0A85EA"><circle cx="12" cy="12" r="10"/><path d="M12 6.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11zm0 3a2.5 2.5 0 0 1 2.5 2.5v1a2.5 2.5 0 0 1-5 0v-1a2.5 2.5 0 0 1 2.5-2.5z" fill="#FFFFFF"/></svg>'};if(t.includes("epic")||t.includes("epicgames"))return{bg:"#1e1e24",color:"#FFFFFF",label:"EPIC",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.5 2.5v19l8.5 2.5 8.5-2.5v-19l-8.5 2.5zm3.5 5.5h10v2.2h-7v2.4h6v2.2h-6v2.4h7v2.2H7z"/></svg>'};if(t.includes("adobe"))return{bg:"#361214",color:"#FF0000",label:"AD",svg:'<svg viewBox="0 0 24 24" fill="#FF0000"><path d="M13.96 2H24v20l-5.63-14.07zM10.04 2H0v20l5.63-14.07zM12 7.74l3.18 7.95h-2.67l-1.28-3.2h-2.1l2.87 7.51H9.41z"/></svg>'};if(t.includes("zoom"))return{bg:"#102340",color:"#2D8CFF",label:"ZM",svg:'<svg viewBox="0 0 24 24" fill="#2D8CFF"><path d="M4 6.5h11c1.1 0 2 .9 2 2v7c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2v-7c0-1.1.9-2 2-2zm14 2.5l4-3v12l-4-3V9z"/></svg>'};if(t.includes("salesforce"))return{bg:"#0e2640",color:"#00A1E0",label:"SF",svg:'<svg viewBox="0 0 24 24" fill="#00A1E0"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/></svg>'};if(t.includes("uber"))return{bg:"#1e1e1e",color:"#FFFFFF",label:"UB",svg:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/><rect x="8.5" y="8.5" width="7" height="7" rx="1" fill="#1e1e1e"/><rect x="9.5" y="11" width="5" height="2" fill="currentColor"/></svg>'};if(t.includes("stripe"))return{bg:"#1c1e38",color:"#635BFF",label:"ST",svg:'<svg viewBox="0 0 24 24" fill="#635BFF"><path d="M13.976 9.15c-2.172-.806-3.356-1.426-3.356-2.409 0-.831.683-1.305 1.901-1.305 2.227 0 4.515.858 6.09 1.631l.89-5.494C18.252.97 16.14.4 13.976.4 8.796.4 5.3 3.12 5.3 7.424c0 4.304 3.496 5.86 6.848 6.993 2.122.718 2.87 1.353 2.87 2.302 0 .976-.879 1.488-2.316 1.488-2.164 0-4.99-.988-6.942-2.074l-.94 5.58c1.942.87 4.542 1.387 7.02 1.387 5.485 0 9.16-2.613 9.16-7.142 0-4.084-3.136-5.882-7.024-6.808z"/></svg>'};let l=0;for(let d=0;d<o.length;d++)l=o.charCodeAt(d)+((l<<5)-l);const a=Math.abs(l%360),b=(o.replace(/[^a-zA-Z0-9]/g,"").slice(0,2)||"2F").toUpperCase();return{bg:`hsl(${a}, 40%, 18%)`,color:`hsl(${a}, 85%, 75%)`,label:b}}const N="buffer-auth-inline-host",T="data-buffer-auth-detected";function P(e){if(e.maxLength!==1&&e.getAttribute("size")!=="1")return null;const s=e.form||(typeof e.closest=="function"?e.closest("form"):null)||e.parentElement;if(!s)return null;const o=Array.from(s.querySelectorAll("input")).filter(r=>(r.maxLength===1||r.getAttribute("size")==="1")&&(r.type==="tel"||r.type==="text"||r.type==="number"||r.type==="password"||r.inputMode==="numeric"));return o.length>=4&&o.length<=8&&o.includes(e)?o:null}function S(e){if(e.hasAttribute(T)||e.type==="hidden"||e.type==="checkbox"||e.type==="radio"||e.type==="submit"||e.type==="button"||e.type==="file"||e.type==="image"||e.disabled||e.readOnly)return!1;const s=P(e);if(s)return s[s.length-1]===e?(s.slice(0,-1).forEach(F=>F.setAttribute(T,"cluster-sibling")),!0):!1;const o=(e.getAttribute("autocomplete")||"").toLowerCase();if(o.includes("one-time-code")||o==="otp"||o==="2fa"||o==="totp")return!0;const r=(e.placeholder||"").trim();if(/^x{6,8}$/i.test(r)||/^x{3}[\s\-_]x{3}$/i.test(r)||/^0{6,8}$/.test(r)||/^[•·]{6,8}$/.test(r)||/^[_\-\s]{6,8}$/.test(r))return!0;const t=f=>f.replace(/([a-z])([A-Z])/g,"$1 $2").replace(/[-_.]/g," ").toLowerCase().trim(),l=t(e.name||""),a=t(e.id||""),b=t(e.placeholder||""),d=t(e.getAttribute("aria-label")||""),z=t(e.title||""),h=`${l} ${a} ${b} ${d} ${z}`;if(["postal","zip","coupon","promo","discount","currency","area","cvv","cvc"].some(f=>h.includes(f)))return!1;const x=["otp","2fa","mfa","totp","verification code","authenticator","two factor","two step","2 factor","2 step","one time code","security code"].some(f=>h.includes(f));if(e.type==="password")return x;if(x||["token","passcode","pass code","pin","idvpin","otc","twofactor","twostep","challenge","verification","verify","auth code","login code","sms code"].some(f=>h.includes(f))||/\bcode\b/i.test(h)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric"||e.maxLength===6||e.maxLength===8||e.size===6||e.size===8||h.includes("auth")||h.includes("security")||h.includes("login")||h.includes("sign in")||h.includes("enter")||e.name.toLowerCase()==="code"||e.id.toLowerCase()==="code"))return!0;const B=e.maxLength;return!!((B===6||B===8)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric")||e.pattern&&/(\[0-9\]|\\d|\d)\{(?:6|8|6,8)\}/.test(e.pattern))}function V(e){return e.length===6?`${e.slice(0,3)} ${e.slice(3)}`:e.length===8?`${e.slice(0,4)} ${e.slice(4)}`:e}function R(e){return e.replace(/[&<>"']/g,s=>{switch(s){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return s}})}function O(e,s){const o=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value")?.set;e.focus(),o?o.call(e,s):e.value=s;try{e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:s}))}catch{e.dispatchEvent(new Event("input",{bubbles:!0}))}e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{key:s,code:`Digit${s}`,bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keyup",{key:s,code:`Digit${s}`,bubbles:!0}))}function U(e,s){const o=s.replace(/\D/g,""),r=P(e)||(()=>{const t=e.form||e.closest("form")||e.parentElement;if(!t)return null;const l=Array.from(t.querySelectorAll("input")).filter(a=>(a.maxLength===1||a.getAttribute("size")==="1")&&(a.type==="tel"||a.type==="text"||a.type==="number"||a.type==="password"||a.inputMode==="numeric"));return l.length>=4&&l.length<=8?l:null})();if(r&&r.length>=o.length){r.forEach((l,a)=>{a<o.length&&O(l,o[a])}),r[Math.min(o.length-1,r.length-1)]?.focus();return}O(e,o)}function H(e){e.setAttribute(T,"true");const s=e.maxLength===1||e.getAttribute("size")==="1";if(!s){const n=window.getComputedStyle(e),i=parseFloat(n.paddingRight)||0;i<34&&(e.style.paddingRight=`${i+30}px`)}const o=document.createElement("div");o.className=N,o.style.position="fixed",o.style.top="0px",o.style.left="0px",o.style.width="0px",o.style.height="0px",o.style.zIndex="2147483646",o.style.pointerEvents="none";const r=o.attachShadow({mode:"open"});r.innerHTML=`
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      /* In-Field Shield App Icon Badge */
      .badge-btn {
        position: fixed;
        width: 24px;
        height: 24px;
        background: linear-gradient(135deg, #004a77 0%, #002d4c 100%);
        border: 1px solid rgba(168, 199, 250, 0.45);
        border-radius: 7px;
        color: #a8c7fa;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        pointer-events: auto;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4), inset 1px 1px 2px rgba(255, 255, 255, 0.18);
        transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
        user-select: none;
        z-index: 2147483646;
      }
      .badge-btn:hover {
        background: linear-gradient(135deg, #005d96 0%, #00375d 100%);
        border-color: #a8c7fa;
        color: #ffffff;
        transform: scale(1.08);
        box-shadow: 0 0 12px rgba(168, 199, 250, 0.55), inset 1px 1px 2px rgba(255, 255, 255, 0.3);
      }
      .badge-btn:active {
        background: linear-gradient(135deg, #0842a0 0%, #004a77 100%);
        transform: scale(0.96);
      }
      .badge-btn.active {
        background: linear-gradient(135deg, #0842a0 0%, #004a77 100%);
        border-color: #a8c7fa;
        color: #ffffff;
        box-shadow: 0 0 14px rgba(168, 199, 250, 0.7);
      }
      .shield-icon {
        width: 14px;
        height: 14px;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
      }

      /* Interactive 2FA Live Card Popover */
      .autofill-popover {
        position: fixed;
        width: 320px;
        background: #171a21;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 14px;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75), 0 4px 12px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(20px);
        color: #e2e2e9;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        padding: 12px;
        pointer-events: auto;
        z-index: 2147483647;
        opacity: 0;
        transform: translateY(-6px) scale(0.97);
        pointer-events: none;
        transition: all 0.18s cubic-bezier(0.2, 0, 0, 1);
      }
      .autofill-popover.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      /* Popover Header */
      .popover-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 10px;
      }
      .popover-title-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .popover-brand {
        font-size: 12px;
        font-weight: 700;
        color: #a8c7fa;
        letter-spacing: 0.2px;
      }
      .popover-domain {
        font-size: 10px;
        color: #9aa0a6;
        background: rgba(255, 255, 255, 0.06);
        padding: 2px 6px;
        border-radius: 4px;
        max-width: 140px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .btn-close-popover {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease;
      }
      .btn-close-popover:hover {
        color: #ffffff;
      }
      .popover-actions-row {
        display: flex;
        align-items: center;
        gap: 2px;
      }
      .btn-popover-lock {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease, background-color 0.15s ease;
      }
      .btn-popover-lock:hover {
        color: #ffb4ab;
        background: rgba(255, 255, 255, 0.06);
      }
      .btn-popover-lock.hidden {
        display: none;
      }

      /* Accounts List */
      .accounts-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 260px;
        overflow-y: auto;
      }
      .account-card {
        background: #20242e;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 10px 12px;
        transition: all 0.15s ease;
      }
      .account-card:hover {
        border-color: rgba(168, 199, 250, 0.35);
        background: #252a36;
      }

      .card-top {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
      }
      .card-avatar {
        width: 22px;
        height: 22px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        flex-shrink: 0;
        overflow: hidden;
      }
      .card-avatar svg {
        width: 14px;
        height: 14px;
      }
      .card-info {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .card-issuer {
        font-size: 12px;
        font-weight: 700;
        color: #ffffff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .card-account {
        font-size: 10.5px;
        color: #9aa0a6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .card-middle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      .card-code {
        font-family: "SFMono-Regular", Consolas, Menlo, monospace;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: 2px;
        color: #a8c7fa;
      }
      .btn-fill-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 6px;
        padding: 5px 12px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.15s ease;
      }
      .btn-fill-action:hover {
        background: #0c4fa0;
        color: #ffffff;
        transform: translateY(-1px);
      }
      .btn-fill-action:active {
        transform: translateY(0);
      }
      .btn-fill-action.filled {
        background: #137333 !important;
        color: #ffffff !important;
      }

      /* Progress Bar & Countdown Timer */
      .card-timer-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .timer-track {
        flex: 1;
        height: 4px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 9999px;
        overflow: hidden;
      }
      .timer-fill {
        height: 100%;
        background: #a8c7fa;
        border-radius: 9999px;
        transition: width 0.3s linear, background-color 0.3s ease;
      }
      .timer-fill.warning {
        background: #ffb951;
      }
      .timer-fill.danger {
        background: #ffb4ab;
      }
      .timer-label {
        font-size: 10px;
        font-weight: 600;
        color: #9aa0a6;
        min-width: 22px;
        text-align: right;
      }

      /* Locked or Empty State */
      .empty-box {
        text-align: center;
        padding: 16px 8px;
        color: #9aa0a6;
        font-size: 11.5px;
        line-height: 1.4;
      }
      .empty-box svg {
        margin-bottom: 6px;
        color: #a8c7fa;
      }
      .empty-box .empty-sub {
        font-size: 10px;
        color: #6c727d;
        margin-top: 4px;
      }

      /* In-Popover Unlock Form */
      .unlock-panel {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding: 2px;
      }
      .unlock-header {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .unlock-icon-badge {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: rgba(168, 199, 250, 0.12);
        border: 1px solid rgba(168, 199, 250, 0.25);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #a8c7fa;
        flex-shrink: 0;
      }
      .unlock-text {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .unlock-title {
        font-size: 13px;
        font-weight: 700;
        color: #ffffff;
        line-height: 1.2;
        margin-bottom: 2px;
      }
      .unlock-desc {
        font-size: 11px;
        color: #9aa0a6;
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .unlock-desc strong {
        color: #a8c7fa;
      }
      .unlock-form {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 2px;
      }
      .unlock-input-row {
        position: relative;
        display: flex;
        align-items: center;
        width: 100%;
      }
      .unlock-password-input {
        width: 100%;
        background: #0e1015;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 8px;
        padding: 8px 34px 8px 10px;
        font-size: 12.5px;
        color: #ffffff;
        outline: none;
        font-family: inherit;
        box-sizing: border-box;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .unlock-password-input:focus {
        border-color: #a8c7fa;
        box-shadow: 0 0 0 2px rgba(168, 199, 250, 0.25);
      }
      .unlock-password-input::placeholder {
        color: #6c727d;
      }
      .btn-toggle-eye {
        position: absolute;
        right: 6px;
        background: transparent;
        border: none;
        color: #80868b;
        cursor: pointer;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: color 0.15s ease;
      }
      .btn-toggle-eye:hover {
        color: #ffffff;
      }
      .unlock-error-msg {
        font-size: 11px;
        color: #ffb4ab;
        background: rgba(147, 0, 10, 0.25);
        border: 1px solid rgba(255, 180, 171, 0.25);
        border-radius: 6px;
        padding: 6px 8px;
        line-height: 1.3;
        animation: shake 0.25s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
      }
      .unlock-error-msg.hidden {
        display: none;
      }
      @keyframes shake {
        10%, 90% { transform: translate3d(-1px, 0, 0); }
        20%, 80% { transform: translate3d(2px, 0, 0); }
        30%, 50%, 70% { transform: translate3d(-3px, 0, 0); }
        40%, 60% { transform: translate3d(3px, 0, 0); }
      }
      .btn-unlock-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 8px;
        padding: 8px 14px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        width: 100%;
        transition: all 0.15s ease;
      }
      .btn-unlock-action:hover:not(:disabled) {
        background: #0b57d0;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(11, 87, 208, 0.4);
      }
      .btn-unlock-action:active:not(:disabled) {
        transform: scale(0.98);
      }
      .btn-unlock-action:disabled {
        opacity: 0.65;
        cursor: not-allowed;
      }
      .spin-icon {
        animation: spin 1s linear infinite;
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    </style>

    <button type="button" class="badge-btn" id="badge-trigger" title="Buffer Authenticator (Click to view live 2FA code)">
      <svg class="shield-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    </button>

    <div class="autofill-popover" id="popover-panel">
      <div class="popover-header">
        <div class="popover-title-row">
          <svg class="shield-icon" style="width: 13px; height: 13px; color: #a8c7fa;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span class="popover-brand">Buffer Authenticator</span>
          <span class="popover-domain" id="domain-label"></span>
        </div>
        <div class="popover-actions-row">
          <button type="button" class="btn-popover-lock hidden" id="btn-popover-lock" title="Lock Vault">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </button>
          <button type="button" class="btn-close-popover" id="btn-close" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="accounts-list" id="accounts-list-container">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `;const t=document.documentElement||document.body;t&&t.appendChild(o);const l=r.getElementById("badge-trigger"),a=r.getElementById("popover-panel"),b=r.getElementById("domain-label"),d=r.getElementById("accounts-list-container"),z=r.getElementById("btn-close"),h=r.getElementById("btn-popover-lock");b.textContent=window.location.hostname;let m=[],w=null,x=!1,y=!1,B=!0;function f(){if(!document.contains(e)){o.remove();return}const n=e.getBoundingClientRect(),i=window.getComputedStyle(e);if(n.bottom<0||n.top>window.innerHeight||n.right<0||n.left>window.innerWidth||n.width===0||n.height===0||i.display==="none"||i.visibility==="hidden"||i.opacity==="0"){l.style.display="none",x&&A();return}l.style.display="flex";const c=24,g=Math.round(n.top+(n.height-c)/2);let p=Math.round(n.right-c-6);s&&(window.innerWidth-n.right>=c+8?p=Math.round(n.right+8):p=Math.round(n.right-c-4)),l.style.top=`${g}px`,l.style.left=`${p}px`,x&&F(n)}function F(n){const i=n||e.getBoundingClientRect(),c=320,g=a.offsetHeight||160,p=Math.max(8,Math.min(i.left,window.innerWidth-c-12));window.innerHeight-i.bottom>=g+10||i.top<g+10?a.style.top=`${Math.round(i.bottom+6)}px`:a.style.top=`${Math.round(i.top-g-6)}px`,a.style.left=`${Math.round(p)}px`}function _(){w&&clearInterval(w),!(y||!B||m.length===0)&&(w=setInterval(async()=>{let n=!1;m.forEach(i=>{i.secondsRemaining-=1,i.secondsRemaining<=0&&(n=!0)}),n?(await D(),$()):W()},1e3))}function $(){if(d.innerHTML="",!B){h.classList.add("hidden"),d.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <p>Vault is not set up</p>
          <p class="empty-sub">Open Buffer Authenticator from your toolbar to set up your master password.</p>
        </div>
      `;return}if(y){h.classList.add("hidden"),d.innerHTML=`
        <div class="unlock-panel">
          <div class="unlock-header">
            <div class="unlock-icon-badge">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            <div class="unlock-text">
              <div class="unlock-title">Vault is Locked</div>
              <div class="unlock-desc">Enter password to unlock 2FA codes</div>
            </div>
          </div>

          <form id="popover-unlock-form" class="unlock-form">
            <div class="unlock-input-row">
              <input
                type="password"
                id="popover-password-input"
                class="unlock-password-input"
                placeholder="Enter master password"
                autocomplete="current-password"
                required
              />
              <button type="button" id="popover-btn-toggle-eye" class="btn-toggle-eye" title="Show/Hide password">
                <svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
              </button>
            </div>

            <div id="popover-unlock-error" class="unlock-error-msg hidden"></div>

            <button type="submit" id="popover-btn-unlock" class="btn-unlock-action">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            </button>
          </form>
        </div>
      `;const n=d.querySelector("#popover-btn-toggle-eye"),i=d.querySelector("#popover-password-input"),c=d.querySelector("#popover-unlock-error"),g=d.querySelector("#popover-unlock-form"),p=d.querySelector("#popover-btn-unlock");let v=!1;n&&i&&n.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),v=!v,i.type=v?"text":"password",n.innerHTML=v?`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>`:`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>`}),i&&(i.addEventListener("keydown",u=>u.stopPropagation()),i.addEventListener("keyup",u=>u.stopPropagation()),i.addEventListener("keypress",u=>u.stopPropagation()),setTimeout(()=>{x&&y&&i.focus()},50)),g&&i&&c&&p&&g.addEventListener("submit",async u=>{u.preventDefault(),u.stopPropagation();const M=i.value;if(M){c.classList.add("hidden"),c.textContent="",p.disabled=!0,p.innerHTML=`
            <svg class="spin-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25"/>
              <path d="M12 2a10 10 0 0 1 10 10"/>
            </svg>
            <span>Unlocking...</span>
          `;try{const L=await chrome.runtime.sendMessage({type:"UNLOCK_VAULT",payload:{password:M}});L&&L.success?(y=!1,await D(),$(),F(),_()):(p.disabled=!1,p.innerHTML=`
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
                </svg>
                <span>Unlock Vault</span>
              `,c.textContent=L?.error||"Incorrect master password",c.classList.remove("hidden"),i.focus(),i.select(),F())}catch(L){p.disabled=!1,p.innerHTML=`
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            `,c.textContent=L?.message||"Failed to unlock vault",c.classList.remove("hidden"),i.focus(),F()}}});return}if(h.classList.remove("hidden"),m.length===0){d.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <p>No 2FA account found for <strong>${R(window.location.hostname)}</strong></p>
          <p class="empty-sub">Add this account in Buffer Authenticator popup</p>
        </div>
      `;return}m.forEach(n=>{const i=document.createElement("div");i.className="account-card",i.setAttribute("data-id",n.id);const c=q(n.issuer,n.account),g=n.period||30,p=Math.max(0,n.secondsRemaining),v=Math.max(0,Math.min(100,p/g*100));let u="";p<=5?u="danger":p<=10&&(u="warning"),i.innerHTML=`
        <div class="card-top">
          <div class="card-avatar" style="background: ${c.bg}; color: ${c.color};">
            ${c.svg?c.svg:c.label}
          </div>
          <div class="card-info">
            <span class="card-issuer" title="${n.issuer||"Account"}">${n.issuer||"Account"}</span>
            <span class="card-account" title="${n.account}">${n.account}</span>
          </div>
        </div>

        <div class="card-middle">
          <span class="card-code" data-code="${n.code}">${V(n.code)}</span>
          <button type="button" class="btn-fill-action" data-fill="${n.code}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span>Fill Code</span>
          </button>
        </div>

        <div class="card-timer-row">
          <div class="timer-track">
            <div class="timer-fill ${u}" style="width: ${v}%;"></div>
          </div>
          <span class="timer-label">${p}s</span>
        </div>
      `;const M=i.querySelector(".btn-fill-action"),L=I=>{I.stopPropagation(),U(e,n.code),M.classList.add("filled"),M.innerHTML=`
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Filled!</span>
        `,setTimeout(()=>{A()},400)};M.addEventListener("click",L),i.addEventListener("click",I=>{I.target.closest(".btn-fill-action")||L(I)}),d.appendChild(i)})}function W(){m.forEach(n=>{const i=d.querySelector(`.account-card[data-id="${n.id}"]`);if(!i)return;const c=n.period||30,g=Math.max(0,n.secondsRemaining),p=Math.max(0,Math.min(100,g/c*100)),v=i.querySelector(".timer-fill"),u=i.querySelector(".timer-label"),M=i.querySelector(".card-code");v&&(v.style.width=`${p}%`,v.className="timer-fill",g<=5?v.classList.add("danger"):g<=10&&v.classList.add("warning")),u&&(u.textContent=`${g}s`),M&&(M.textContent=V(n.code))})}async function D(){try{const n={type:"GET_CODE_FOR_DOMAIN",payload:{domain:window.location.hostname}},i=await chrome.runtime.sendMessage(n);if(i&&i.success&&i.data)return y=!!i.data.isLocked,B=i.data.isInitialized!==!1,i.data.matched&&i.data.matched.length>0?m=i.data.matched:i.data.all&&i.data.all.length>0?m=i.data.all:m=[],!0;try{const c=await chrome.runtime.sendMessage({type:"GET_STATUS"});c&&c.success&&c.data&&(y=!!c.data.isLocked,B=!!c.data.isInitialized)}catch{y=!1}return m=[],!1}catch{return m=[],y=!1,!1}}async function Y(){x=!0,l.classList.add("active"),d.innerHTML=`
      <div class="empty-box">
        <p>Loading live 2FA code...</p>
      </div>
    `,a.classList.add("open"),F(),await D(),$(),F(),_()}function A(){x=!1,l.classList.remove("active"),a.classList.remove("open"),w&&(clearInterval(w),w=null)}l.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),x?A():Y()}),z.addEventListener("click",n=>{n.stopPropagation(),A()}),h.addEventListener("click",async n=>{n.stopPropagation();try{await chrome.runtime.sendMessage({type:"LOCK_VAULT"})}catch{}y=!0,m=[],w&&(clearInterval(w),w=null),$(),F()}),a.addEventListener("click",n=>{n.stopPropagation()}),document.addEventListener("click",n=>{if(!x)return;const i=n.target;i!==e&&!o.contains(i)&&A()}),document.addEventListener("keydown",n=>{n.key==="Escape"&&x&&A()}),window.addEventListener("scroll",f,{passive:!0,capture:!0}),window.addEventListener("resize",f,{passive:!0}),new ResizeObserver(()=>{f()}).observe(e),e.addEventListener("focus",f),e.addEventListener("input",f),f(),requestAnimationFrame(f)}const j='input[autocomplete*="one-time-code" i], input[autocomplete="2fa" i], input[name*="otp" i], input[name*="2fa" i], input[name*="mfa" i], input[name*="totp" i], input[name*="code" i], input[name*="token" i], input[name*="pin" i], input[name*="passcode" i], input[name*="twofactor" i], input[name*="twostep" i], input[id*="otp" i], input[id*="2fa" i], input[id*="totp" i], input[id*="code" i], input[id*="token" i], input[id*="pin" i], input[id*="passcode" i], input[placeholder*="code" i], input[placeholder*="otp" i], input[placeholder*="token" i], input[placeholder*="pin" i], input[type="tel"], input[type="number"], input[inputmode="numeric"]';function k(e=document){if(e.querySelectorAll(j).forEach(o=>{S(o)&&H(o)}),e===document){const o=document.querySelectorAll("input");o.length<80&&o.forEach(r=>{S(r)&&H(r)})}}if(typeof document<"u"){let e=function(){const o=document.documentElement||document.body;o&&s.observe(o,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","style","hidden","type","disabled"]})};k(),document.readyState==="loading"&&document.addEventListener("DOMContentLoaded",()=>k()),typeof window<"u"&&(window.addEventListener("load",()=>k()),setTimeout(()=>k(),150),setTimeout(()=>k(),500),setTimeout(()=>k(),1200));const s=new MutationObserver(o=>{let r=!1;for(let t=0;t<o.length;t++){const l=o[t];if(l.type==="childList"){const a=l.addedNodes;for(let b=0;b<a.length;b++){const d=a[b];if(d.nodeType===1){const z=d;z.tagName==="INPUT"&&S(z)?H(z):z.firstElementChild&&k(z)}}}else l.type==="attributes"&&(r=!0)}r&&(k(),window.dispatchEvent(new Event("resize")))});e(),document.addEventListener("focusin",o=>{const r=o.target;r instanceof HTMLInputElement&&(S(r)?H(r):r.hasAttribute(T)&&window.dispatchEvent(new Event("resize")))},!0),document.addEventListener("visibilitychange",()=>{document.hidden?s.disconnect():(k(),e())})}let E=null;typeof document<"u"&&document.addEventListener("contextmenu",e=>{E=e.target},!0);function C(e,s="success"){let o=document.getElementById("buffer-auth-toast-container");o||(o=document.createElement("div"),o.id="buffer-auth-toast-container",o.style.cssText=`
      position: fixed;
      top: 24px;
      right: 24px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `,document.body.appendChild(o));const r=document.createElement("div"),t=s==="error"?"#2A1818":s==="warning"?"#2A2214":"#141E28",l=s==="error"?"#FF6B6B":s==="warning"?"#FFB951":"#A8C7FA",a=s==="error"?"#FFDADA":s==="warning"?"#FFF2D6":"#E2E2E9",b=s==="error"?"✕":s==="warning"?"⚠":"✓";r.style.cssText=`
    display: flex;
    align-items: center;
    gap: 12px;
    background: ${t};
    border: 1px solid ${l};
    color: ${a};
    padding: 12px 18px;
    border-radius: 16px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.55), inset 1px 1px 2px rgba(255, 255, 255, 0.12);
    font-size: 13.5px;
    font-weight: 600;
    pointer-events: auto;
    transform: translateY(-10px);
    opacity: 0;
    transition: all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  `,r.innerHTML=`
    <span style="font-size: 16px; color: ${l}; font-weight: 800;">${b}</span>
    <span>${R(e)}</span>
  `,o.appendChild(r),requestAnimationFrame(()=>{r.style.transform="translateY(0)",r.style.opacity="1"}),setTimeout(()=>{r.style.transform="translateY(-10px)",r.style.opacity="0",setTimeout(()=>r.remove(),300)},4200)}async function G(e){C("Scanning QR code with Buffer Authenticator...","warning");try{if(!("BarcodeDetector"in window)){C("BarcodeDetector API is unavailable in this browser","error");return}let s=null;if(E instanceof HTMLImageElement&&(E.currentSrc||E.src)||E instanceof HTMLCanvasElement?s=E:e&&(s=await new Promise((a,b)=>{const d=new Image;d.crossOrigin="anonymous",d.onload=()=>a(d),d.onerror=()=>b(new Error("Failed to load image from page URL")),d.src=e})),!s){C("Could not find image element to scan","error");return}const r=await new window.BarcodeDetector({formats:["qr_code"]}).detect(s);if(!r||r.length===0){C("No QR code detected in the selected image","error");return}const t=r[0].rawValue,l=await chrome.runtime.sendMessage({type:"IMPORT_VAULT",payload:{data:t}});if(l.success&&l.data)C(`✓ Added ${l.data.importedCount} account(s) to Buffer Authenticator!`,"success");else{const a=l.error||"Failed to import account";a.toLowerCase().includes("locked")?C("Buffer Authenticator is locked! Please unlock your vault first.","warning"):C(a,"error")}}catch(s){C(s.message||"Error scanning QR code","error")}}typeof chrome<"u"&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((e,s,o)=>{e.type==="CONTEXT_MENU_SCAN_QR"&&(G(e.srcUrl),o({received:!0}))})})();
