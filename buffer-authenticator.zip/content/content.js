const P="buffer-auth-inline-host",T="data-buffer-auth-detected";function C(e){if(e.hasAttribute(T)||e.type==="password"||e.type==="hidden"||e.type==="checkbox"||e.type==="radio"||e.disabled||e.readOnly)return!1;if((e.getAttribute("autocomplete")||"").toLowerCase()==="one-time-code")return!0;const i=(e.name||"").toLowerCase(),n=(e.id||"").toLowerCase(),r=(e.placeholder||"").toLowerCase(),a=(e.getAttribute("aria-label")||"").toLowerCase();if(["otp","2fa","mfa","totp","token","verification_code","security code","authenticator","two-factor","two_factor"].some(b=>i.includes(b)||n.includes(b)||r.includes(b)||a.includes(b)))return!0;const u=e.maxLength;return(u===6||u===8)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric")}function H(e){const s=(e||"").toLowerCase().trim();if(s.includes("google"))return{bg:"#1a2332",color:"#4285F4",label:"G"};if(s.includes("github"))return{bg:"#24292e",color:"#ffffff",label:"GH"};if(s.includes("microsoft"))return{bg:"#182538",color:"#00a4ef",label:"MS"};if(s.includes("facebook")||s.includes("meta"))return{bg:"#0c2e59",color:"#1877f2",label:"FB"};if(s.includes("twitter")||s.includes("x"))return{bg:"#1b222d",color:"#ffffff",label:"X"};let i=0;for(let r=0;r<s.length;r++)i=s.charCodeAt(r)+((i<<5)-i);const n=Math.abs(i%360);return{bg:`hsl(${n}, 40%, 18%)`,color:`hsl(${n}, 85%, 75%)`,label:(e.slice(0,2)||"2F").toUpperCase()}}function z(e){return e.length===6?`${e.slice(0,3)} ${e.slice(3)}`:e.length===8?`${e.slice(0,4)} ${e.slice(4)}`:e}function N(e,s){const i=s.replace(/\s+/g,"");if(e.maxLength===1){const n=e.form||e.closest("form")||e.parentElement;if(n){const r=Array.from(n.querySelectorAll("input")).filter(a=>a.maxLength===1&&(a.type==="tel"||a.type==="text"||a.type==="number"||a.inputMode==="numeric"));if(r.length>=i.length){r.forEach((c,E)=>{E<i.length&&(c.value=i[E],c.dispatchEvent(new Event("input",{bubbles:!0})),c.dispatchEvent(new Event("change",{bubbles:!0})))}),r[Math.min(i.length-1,r.length-1)]?.focus();return}}}e.value=i,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus()}function M(e){e.setAttribute(T,"true");const s=window.getComputedStyle(e),i=parseFloat(s.paddingRight)||0;i<34&&(e.style.paddingRight=`${i+30}px`);const n=document.createElement("div");n.className=P,n.style.position="fixed",n.style.top="0px",n.style.left="0px",n.style.width="0px",n.style.height="0px",n.style.zIndex="2147483646",n.style.pointerEvents="none";const r=n.attachShadow({mode:"open"});r.innerHTML=`
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      /* In-Field Shield App Icon Badge */
      .badge-btn {
        position: fixed;
        width: 24px;
        height: 24px;
        background: #111318;
        border: 1px solid rgba(168, 199, 250, 0.35);
        border-radius: 6px;
        color: #a8c7fa;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        pointer-events: auto;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.35);
        transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
        user-select: none;
        z-index: 2147483646;
      }
      .badge-btn:hover {
        background: #1e222a;
        border-color: #a8c7fa;
        color: #ffffff;
        transform: scale(1.08);
        box-shadow: 0 0 10px rgba(168, 199, 250, 0.45);
      }
      .badge-btn:active {
        transform: scale(0.96);
      }
      .badge-btn.active {
        background: #0842a0;
        border-color: #a8c7fa;
        color: #ffffff;
      }
      .shield-icon {
        width: 14px;
        height: 14px;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
      }

      /* Interactive 2FA Live Card Popover */
      .autofill-popover {
        position: fixed;
        width: 320px;
        background: #171a21;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 14px;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75), 0 4px 12px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(20px);
        color: #e2e2e9;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        padding: 12px;
        pointer-events: auto;
        z-index: 2147483647;
        opacity: 0;
        transform: translateY(-6px) scale(0.97);
        pointer-events: none;
        transition: all 0.18s cubic-bezier(0.2, 0, 0, 1);
      }
      .autofill-popover.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      /* Popover Header */
      .popover-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 10px;
      }
      .popover-title-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .popover-brand {
        font-size: 12px;
        font-weight: 700;
        color: #a8c7fa;
        letter-spacing: 0.2px;
      }
      .popover-domain {
        font-size: 10px;
        color: #9aa0a6;
        background: rgba(255, 255, 255, 0.06);
        padding: 2px 6px;
        border-radius: 4px;
        max-width: 140px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .btn-close-popover {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease;
      }
      .btn-close-popover:hover {
        color: #ffffff;
      }

      /* Accounts List */
      .accounts-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 260px;
        overflow-y: auto;
      }
      .account-card {
        background: #20242e;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 10px 12px;
        transition: all 0.15s ease;
      }
      .account-card:hover {
        border-color: rgba(168, 199, 250, 0.35);
        background: #252a36;
      }

      .card-top {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
      }
      .card-avatar {
        width: 22px;
        height: 22px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        flex-shrink: 0;
      }
      .card-info {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .card-issuer {
        font-size: 12px;
        font-weight: 700;
        color: #ffffff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .card-account {
        font-size: 10.5px;
        color: #9aa0a6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .card-middle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      .card-code {
        font-family: "SFMono-Regular", Consolas, Menlo, monospace;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: 2px;
        color: #a8c7fa;
      }
      .btn-fill-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 6px;
        padding: 5px 12px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.15s ease;
      }
      .btn-fill-action:hover {
        background: #0c4fa0;
        color: #ffffff;
        transform: translateY(-1px);
      }
      .btn-fill-action:active {
        transform: translateY(0);
      }
      .btn-fill-action.filled {
        background: #137333 !important;
        color: #ffffff !important;
      }

      /* Progress Bar & Countdown Timer */
      .card-timer-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .timer-track {
        flex: 1;
        height: 4px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 9999px;
        overflow: hidden;
      }
      .timer-fill {
        height: 100%;
        background: #a8c7fa;
        border-radius: 9999px;
        transition: width 0.3s linear, background-color 0.3s ease;
      }
      .timer-fill.warning {
        background: #ffb951;
      }
      .timer-fill.danger {
        background: #ffb4ab;
      }
      .timer-label {
        font-size: 10px;
        font-weight: 600;
        color: #9aa0a6;
        min-width: 22px;
        text-align: right;
      }

      /* Locked or Empty State */
      .empty-box {
        text-align: center;
        padding: 16px 8px;
        color: #9aa0a6;
        font-size: 11.5px;
        line-height: 1.4;
      }
      .empty-box svg {
        margin-bottom: 6px;
        color: #a8c7fa;
      }
    </style>

    <button type="button" class="badge-btn" id="badge-trigger" title="Buffer Authenticator (Click to view live 2FA code)">
      <svg class="shield-icon" viewBox="0 0 24 24">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    </button>

    <div class="autofill-popover" id="popover-panel">
      <div class="popover-header">
        <div class="popover-title-row">
          <svg class="shield-icon" style="width: 13px; height: 13px; color: #a8c7fa;" viewBox="0 0 24 24">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span class="popover-brand">Buffer Authenticator</span>
          <span class="popover-domain" id="domain-label"></span>
        </div>
        <button type="button" class="btn-close-popover" id="btn-close" title="Close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      <div class="accounts-list" id="accounts-list-container">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `,document.body.appendChild(n);const a=r.getElementById("badge-trigger"),c=r.getElementById("popover-panel"),E=r.getElementById("domain-label"),u=r.getElementById("accounts-list-container"),b=r.getElementById("btn-close");E.textContent=window.location.hostname;let f=[],m=null,h=!1;function v(){if(!document.contains(e)){n.remove();return}const t=e.getBoundingClientRect(),o=window.getComputedStyle(e);if(t.width===0||t.height===0||o.display==="none"||o.visibility==="hidden"){a.style.display="none",h&&x();return}a.style.display="flex";const d=24,l=Math.round(t.top+(t.height-d)/2),p=Math.round(t.right-d-6);a.style.top=`${l}px`,a.style.left=`${p}px`,h&&L(t)}function L(t){const o=t||e.getBoundingClientRect(),d=320,l=c.offsetHeight||160,p=Math.max(8,Math.min(o.left,window.innerWidth-d-12));window.innerHeight-o.bottom>=l+10||o.top<l+10?c.style.top=`${Math.round(o.bottom+6)}px`:c.style.top=`${Math.round(o.top-l-6)}px`,c.style.left=`${Math.round(p)}px`}function $(){if(u.innerHTML="",f.length===0){u.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <p>No 2FA account found for <strong>${window.location.hostname}</strong></p>
        </div>
      `;return}f.forEach(t=>{const o=document.createElement("div");o.className="account-card",o.setAttribute("data-id",t.id);const d=H(t.issuer||t.account),l=t.period||30,p=Math.max(0,t.secondsRemaining),g=Math.max(0,Math.min(100,p/l*100));let y="";p<=5?y="danger":p<=10&&(y="warning"),o.innerHTML=`
        <div class="card-top">
          <div class="card-avatar" style="background: ${d.bg}; color: ${d.color};">
            ${d.label}
          </div>
          <div class="card-info">
            <span class="card-issuer" title="${t.issuer||"Account"}">${t.issuer||"Account"}</span>
            <span class="card-account" title="${t.account}">${t.account}</span>
          </div>
        </div>

        <div class="card-middle">
          <span class="card-code" data-code="${t.code}">${z(t.code)}</span>
          <button type="button" class="btn-fill-action" data-fill="${t.code}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span>Fill Code</span>
          </button>
        </div>

        <div class="card-timer-row">
          <div class="timer-track">
            <div class="timer-fill ${y}" style="width: ${g}%;"></div>
          </div>
          <span class="timer-label">${p}s</span>
        </div>
      `;const w=o.querySelector(".btn-fill-action"),S=k=>{k.stopPropagation(),N(e,t.code),w.classList.add("filled"),w.innerHTML=`
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Filled!</span>
        `,setTimeout(()=>{x()},400)};w.addEventListener("click",S),o.addEventListener("click",k=>{k.target.closest(".btn-fill-action")||S(k)}),u.appendChild(o)})}function R(){f.forEach(t=>{const o=u.querySelector(`.account-card[data-id="${t.id}"]`);if(!o)return;const d=t.period||30,l=Math.max(0,t.secondsRemaining),p=Math.max(0,Math.min(100,l/d*100)),g=o.querySelector(".timer-fill"),y=o.querySelector(".timer-label"),w=o.querySelector(".card-code");g&&(g.style.width=`${p}%`,g.className="timer-fill",l<=5?g.classList.add("danger"):l<=10&&g.classList.add("warning")),y&&(y.textContent=`${l}s`),w&&(w.textContent=z(t.code))})}async function B(){try{const t={type:"GET_CODE_FOR_DOMAIN",payload:{domain:window.location.hostname}},o=await chrome.runtime.sendMessage(t);return o&&o.success&&o.data?(o.data.matched&&o.data.matched.length>0?f=o.data.matched:o.data.all&&o.data.all.length>0?f=o.data.all:f=[],!0):(f=[],!1)}catch{return f=[],!1}}async function O(){h=!0,a.classList.add("active"),u.innerHTML=`
      <div class="empty-box">
        <p>Loading live 2FA code...</p>
      </div>
    `,c.classList.add("open"),L(),await B(),$(),L(),m&&clearInterval(m),m=setInterval(async()=>{let t=!1;f.forEach(o=>{o.secondsRemaining-=1,o.secondsRemaining<=0&&(t=!0)}),t?(await B(),$()):R()},1e3)}function x(){h=!1,a.classList.remove("active"),c.classList.remove("open"),m&&(clearInterval(m),m=null)}a.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),h?x():O()}),b.addEventListener("click",t=>{t.stopPropagation(),x()}),document.addEventListener("click",t=>{if(!h)return;const o=t.target;o!==e&&!n.contains(o)&&x()}),document.addEventListener("keydown",t=>{t.key==="Escape"&&h&&x()}),window.addEventListener("scroll",v,{passive:!0,capture:!0}),window.addEventListener("resize",v,{passive:!0}),new ResizeObserver(()=>{v()}).observe(e),e.addEventListener("focus",v),e.addEventListener("input",v),v()}const _='input[autocomplete="one-time-code"], input[name*="otp" i], input[name*="2fa" i], input[name*="mfa" i], input[name*="code" i], input[id*="otp" i], input[id*="2fa" i], input[id*="code" i], input[placeholder*="code" i], input[type="tel"], input[type="number"]';function A(e=document){if(e.querySelectorAll(_).forEach(i=>{C(i)&&M(i)}),e===document){const i=document.querySelectorAll("input");i.length<60&&i.forEach(n=>{C(n)&&M(n)})}}A();const F=new MutationObserver(e=>{for(let s=0;s<e.length;s++){const i=e[s].addedNodes;for(let n=0;n<i.length;n++){const r=i[n];if(r.nodeType===1){const a=r;a.tagName==="INPUT"&&C(a)?M(a):a.firstElementChild&&A(a)}}}});function I(){const e=document.body||document.documentElement;e&&F.observe(e,{childList:!0,subtree:!0})}I();document.addEventListener("visibilitychange",()=>{document.hidden?F.disconnect():(A(),I())});
