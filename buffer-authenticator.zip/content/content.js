const g="aegis-auth-chip-host",h="data-aegis-detected";function p(e){if(e.hasAttribute(h)||e.type==="password"||e.type==="hidden"||e.type==="checkbox"||e.type==="radio"||e.disabled||e.readOnly)return!1;if((e.getAttribute("autocomplete")||"").toLowerCase()==="one-time-code")return!0;const o=(e.name||"").toLowerCase(),n=(e.id||"").toLowerCase(),s=(e.placeholder||"").toLowerCase(),i=(e.getAttribute("aria-label")||"").toLowerCase();if(["otp","2fa","mfa","totp","token","verification_code","security code","authenticator"].some(a=>o.includes(a)||n.includes(a)||s.includes(a)||i.includes(a)))return!0;const r=e.maxLength;return(r===6||r===8)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric")}function u(e){e.setAttribute(h,"true");const t=document.createElement("div");t.className=g,t.style.display="inline-flex",t.style.position="relative",t.style.verticalAlign="middle",t.style.marginLeft="8px",t.style.zIndex="2147483640";const o=t.attachShadow({mode:"closed"});o.innerHTML=`
    <style>
      .chip-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: linear-gradient(135deg, #1e293b, #0f172a);
        color: #38bdf8;
        border: 1px solid rgba(56, 189, 248, 0.4);
        border-radius: 9999px;
        padding: 5px 12px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        user-select: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      }
      .chip-btn:hover {
        background: linear-gradient(135deg, #0284c7, #0369a1);
        color: #ffffff;
        border-color: #38bdf8;
        box-shadow: 0 4px 12px rgba(2, 132, 199, 0.4);
        transform: translateY(-1px);
      }
      .chip-btn:active {
        transform: translateY(0);
      }
      .icon {
        width: 14px;
        height: 14px;
        fill: currentColor;
      }
      .chip-tooltip {
        position: absolute;
        bottom: calc(100% + 6px);
        left: 50%;
        transform: translateX(-50%);
        background: #0f172a;
        color: #f8fafc;
        border: 1px solid #334155;
        border-radius: 6px;
        padding: 4px 8px;
        font-size: 11px;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.2s;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      }
      .chip-tooltip.show {
        opacity: 1;
      }
      .success {
        background: #10b981 !important;
        color: #ffffff !important;
        border-color: #059669 !important;
      }
    </style>
    <div style="position: relative;">
      <button type="button" class="chip-btn" id="autofill-btn" title="Fill 2FA code with Buffer Authenticator">
        <svg class="icon" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>
        <span id="label-text">Fill 2FA</span>
      </button>
      <div class="chip-tooltip" id="tooltip"></div>
    </div>
  `;const n=o.getElementById("autofill-btn"),s=o.getElementById("label-text"),i=o.getElementById("tooltip");function d(c,r=2500){i.textContent=c,i.classList.add("show"),setTimeout(()=>{i.classList.remove("show")},r)}n.addEventListener("click",async c=>{c.preventDefault(),c.stopPropagation();try{const r={type:"GET_CODE_FOR_DOMAIN",payload:{domain:window.location.hostname}},a=await chrome.runtime.sendMessage(r);if(!a||!a.success){d(a?.error||"Vault locked. Open Buffer Authenticator to unlock.");return}const l=a.data;if(!l||!l.code){d(`No 2FA account found for ${window.location.hostname}`);return}e.value=l.code,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),n.classList.add("success"),s.textContent="Filled!",setTimeout(()=>{n.classList.remove("success"),s.textContent="Fill 2FA"},2e3)}catch{d("Please unlock Buffer Authenticator")}}),e.parentNode&&(e.nextSibling?e.parentNode.insertBefore(t,e.nextSibling):e.parentNode.appendChild(t))}const y='input[autocomplete="one-time-code"], input[name*="otp" i], input[name*="2fa" i], input[name*="mfa" i], input[name*="code" i], input[id*="otp" i], input[id*="2fa" i], input[id*="code" i], input[placeholder*="code" i], input[type="tel"], input[type="number"]';function f(e=document){if(e.querySelectorAll(y).forEach(o=>{p(o)&&u(o)}),e===document){const o=document.querySelectorAll("input");o.length<50&&o.forEach(n=>{p(n)&&u(n)})}}f();const m=new MutationObserver(e=>{for(let t=0;t<e.length;t++){const o=e[t].addedNodes;for(let n=0;n<o.length;n++){const s=o[n];if(s.nodeType===1){const i=s;i.tagName==="INPUT"&&p(i)?u(i):i.firstElementChild&&f(i)}}}});function b(){const e=document.body||document.documentElement;e&&m.observe(e,{childList:!0,subtree:!0})}b();document.addEventListener("visibilitychange",()=>{document.hidden?m.disconnect():(f(),b())});
