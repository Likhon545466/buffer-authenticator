const _="buffer-auth-inline-host",R="data-buffer-auth-detected";function S(e){if(e.hasAttribute(R)||e.type==="password"||e.type==="hidden"||e.type==="checkbox"||e.type==="radio"||e.disabled||e.readOnly)return!1;if((e.getAttribute("autocomplete")||"").toLowerCase()==="one-time-code")return!0;const r=(e.name||"").toLowerCase(),n=(e.id||"").toLowerCase(),l=(e.placeholder||"").toLowerCase(),s=(e.getAttribute("aria-label")||"").toLowerCase();if(["otp","2fa","mfa","totp","token","verification_code","security code","authenticator","two-factor","two_factor"].some(k=>r.includes(k)||n.includes(k)||l.includes(k)||s.includes(k)))return!0;const p=e.maxLength;return(p===6||p===8)&&(e.type==="tel"||e.type==="number"||e.inputMode==="numeric")}function U(e){const a=(e||"").toLowerCase().trim();if(a.includes("google"))return{bg:"#1a2332",color:"#4285F4",label:"G"};if(a.includes("github"))return{bg:"#24292e",color:"#ffffff",label:"GH"};if(a.includes("microsoft"))return{bg:"#182538",color:"#00a4ef",label:"MS"};if(a.includes("facebook")||a.includes("meta"))return{bg:"#0c2e59",color:"#1877f2",label:"FB"};if(a.includes("twitter")||a.includes("x"))return{bg:"#1b222d",color:"#ffffff",label:"X"};let r=0;for(let l=0;l<a.length;l++)r=a.charCodeAt(l)+((r<<5)-r);const n=Math.abs(r%360);return{bg:`hsl(${n}, 40%, 18%)`,color:`hsl(${n}, 85%, 75%)`,label:(e.slice(0,2)||"2F").toUpperCase()}}function F(e){return e.length===6?`${e.slice(0,3)} ${e.slice(3)}`:e.length===8?`${e.slice(0,4)} ${e.slice(4)}`:e}function N(e){return e.replace(/[&<>"']/g,a=>{switch(a){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return a}})}function j(e,a){const r=a.replace(/\s+/g,"");if(e.maxLength===1){const n=e.form||e.closest("form")||e.parentElement;if(n){const l=Array.from(n.querySelectorAll("input")).filter(s=>s.maxLength===1&&(s.type==="tel"||s.type==="text"||s.type==="number"||s.inputMode==="numeric"));if(l.length>=r.length){l.forEach((g,C)=>{C<r.length&&(g.value=r[C],g.dispatchEvent(new Event("input",{bubbles:!0})),g.dispatchEvent(new Event("change",{bubbles:!0})))}),l[Math.min(r.length-1,l.length-1)]?.focus();return}}}e.value=r,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus()}function I(e){e.setAttribute(R,"true");const a=window.getComputedStyle(e),r=parseFloat(a.paddingRight)||0;r<34&&(e.style.paddingRight=`${r+30}px`);const n=document.createElement("div");n.className=_,n.style.position="fixed",n.style.top="0px",n.style.left="0px",n.style.width="0px",n.style.height="0px",n.style.zIndex="2147483646",n.style.pointerEvents="none";const l=n.attachShadow({mode:"open"});l.innerHTML=`
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      /* In-Field Shield App Icon Badge */
      .badge-btn {
        position: fixed;
        width: 24px;
        height: 24px;
        background: #111318;
        border: 1px solid rgba(168, 199, 250, 0.35);
        border-radius: 6px;
        color: #a8c7fa;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        pointer-events: auto;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.35);
        transition: all 0.2s cubic-bezier(0.2, 0, 0, 1);
        user-select: none;
        z-index: 2147483646;
      }
      .badge-btn:hover {
        background: #1e222a;
        border-color: #a8c7fa;
        color: #ffffff;
        transform: scale(1.08);
        box-shadow: 0 0 10px rgba(168, 199, 250, 0.45);
      }
      .badge-btn:active {
        transform: scale(0.96);
      }
      .badge-btn.active {
        background: #0842a0;
        border-color: #a8c7fa;
        color: #ffffff;
      }
      .shield-icon {
        width: 14px;
        height: 14px;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
      }

      /* Interactive 2FA Live Card Popover */
      .autofill-popover {
        position: fixed;
        width: 320px;
        background: #171a21;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 14px;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75), 0 4px 12px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(20px);
        color: #e2e2e9;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        padding: 12px;
        pointer-events: auto;
        z-index: 2147483647;
        opacity: 0;
        transform: translateY(-6px) scale(0.97);
        pointer-events: none;
        transition: all 0.18s cubic-bezier(0.2, 0, 0, 1);
      }
      .autofill-popover.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      /* Popover Header */
      .popover-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 10px;
      }
      .popover-title-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .popover-brand {
        font-size: 12px;
        font-weight: 700;
        color: #a8c7fa;
        letter-spacing: 0.2px;
      }
      .popover-domain {
        font-size: 10px;
        color: #9aa0a6;
        background: rgba(255, 255, 255, 0.06);
        padding: 2px 6px;
        border-radius: 4px;
        max-width: 140px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .btn-close-popover {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease;
      }
      .btn-close-popover:hover {
        color: #ffffff;
      }
      .popover-actions-row {
        display: flex;
        align-items: center;
        gap: 2px;
      }
      .btn-popover-lock {
        background: transparent;
        border: none;
        color: #9aa0a6;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.15s ease, background-color 0.15s ease;
      }
      .btn-popover-lock:hover {
        color: #ffb4ab;
        background: rgba(255, 255, 255, 0.06);
      }
      .btn-popover-lock.hidden {
        display: none;
      }

      /* Accounts List */
      .accounts-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 260px;
        overflow-y: auto;
      }
      .account-card {
        background: #20242e;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 10px 12px;
        transition: all 0.15s ease;
      }
      .account-card:hover {
        border-color: rgba(168, 199, 250, 0.35);
        background: #252a36;
      }

      .card-top {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
      }
      .card-avatar {
        width: 22px;
        height: 22px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        flex-shrink: 0;
      }
      .card-info {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .card-issuer {
        font-size: 12px;
        font-weight: 700;
        color: #ffffff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .card-account {
        font-size: 10.5px;
        color: #9aa0a6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .card-middle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      .card-code {
        font-family: "SFMono-Regular", Consolas, Menlo, monospace;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: 2px;
        color: #a8c7fa;
      }
      .btn-fill-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 6px;
        padding: 5px 12px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.15s ease;
      }
      .btn-fill-action:hover {
        background: #0c4fa0;
        color: #ffffff;
        transform: translateY(-1px);
      }
      .btn-fill-action:active {
        transform: translateY(0);
      }
      .btn-fill-action.filled {
        background: #137333 !important;
        color: #ffffff !important;
      }

      /* Progress Bar & Countdown Timer */
      .card-timer-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .timer-track {
        flex: 1;
        height: 4px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 9999px;
        overflow: hidden;
      }
      .timer-fill {
        height: 100%;
        background: #a8c7fa;
        border-radius: 9999px;
        transition: width 0.3s linear, background-color 0.3s ease;
      }
      .timer-fill.warning {
        background: #ffb951;
      }
      .timer-fill.danger {
        background: #ffb4ab;
      }
      .timer-label {
        font-size: 10px;
        font-weight: 600;
        color: #9aa0a6;
        min-width: 22px;
        text-align: right;
      }

      /* Locked or Empty State */
      .empty-box {
        text-align: center;
        padding: 16px 8px;
        color: #9aa0a6;
        font-size: 11.5px;
        line-height: 1.4;
      }
      .empty-box svg {
        margin-bottom: 6px;
        color: #a8c7fa;
      }
      .empty-box .empty-sub {
        font-size: 10px;
        color: #6c727d;
        margin-top: 4px;
      }

      /* In-Popover Unlock Form */
      .unlock-panel {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding: 2px;
      }
      .unlock-header {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .unlock-icon-badge {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: rgba(168, 199, 250, 0.12);
        border: 1px solid rgba(168, 199, 250, 0.25);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #a8c7fa;
        flex-shrink: 0;
      }
      .unlock-text {
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .unlock-title {
        font-size: 13px;
        font-weight: 700;
        color: #ffffff;
        line-height: 1.2;
        margin-bottom: 2px;
      }
      .unlock-desc {
        font-size: 11px;
        color: #9aa0a6;
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .unlock-desc strong {
        color: #a8c7fa;
      }
      .unlock-form {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 2px;
      }
      .unlock-input-row {
        position: relative;
        display: flex;
        align-items: center;
        width: 100%;
      }
      .unlock-password-input {
        width: 100%;
        background: #0e1015;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 8px;
        padding: 8px 34px 8px 10px;
        font-size: 12.5px;
        color: #ffffff;
        outline: none;
        font-family: inherit;
        box-sizing: border-box;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .unlock-password-input:focus {
        border-color: #a8c7fa;
        box-shadow: 0 0 0 2px rgba(168, 199, 250, 0.25);
      }
      .unlock-password-input::placeholder {
        color: #6c727d;
      }
      .btn-toggle-eye {
        position: absolute;
        right: 6px;
        background: transparent;
        border: none;
        color: #80868b;
        cursor: pointer;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: color 0.15s ease;
      }
      .btn-toggle-eye:hover {
        color: #ffffff;
      }
      .unlock-error-msg {
        font-size: 11px;
        color: #ffb4ab;
        background: rgba(147, 0, 10, 0.25);
        border: 1px solid rgba(255, 180, 171, 0.25);
        border-radius: 6px;
        padding: 6px 8px;
        line-height: 1.3;
        animation: shake 0.25s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
      }
      .unlock-error-msg.hidden {
        display: none;
      }
      @keyframes shake {
        10%, 90% { transform: translate3d(-1px, 0, 0); }
        20%, 80% { transform: translate3d(2px, 0, 0); }
        30%, 50%, 70% { transform: translate3d(-3px, 0, 0); }
        40%, 60% { transform: translate3d(3px, 0, 0); }
      }
      .btn-unlock-action {
        background: #0842a0;
        color: #d3e3fd;
        border: none;
        border-radius: 8px;
        padding: 8px 14px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        width: 100%;
        transition: all 0.15s ease;
      }
      .btn-unlock-action:hover:not(:disabled) {
        background: #0b57d0;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(11, 87, 208, 0.4);
      }
      .btn-unlock-action:active:not(:disabled) {
        transform: scale(0.98);
      }
      .btn-unlock-action:disabled {
        opacity: 0.65;
        cursor: not-allowed;
      }
      .spin-icon {
        animation: spin 1s linear infinite;
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    </style>

    <button type="button" class="badge-btn" id="badge-trigger" title="Buffer Authenticator (Click to view live 2FA code)">
      <svg class="shield-icon" viewBox="0 0 24 24">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    </button>

    <div class="autofill-popover" id="popover-panel">
      <div class="popover-header">
        <div class="popover-title-row">
          <svg class="shield-icon" style="width: 13px; height: 13px; color: #a8c7fa;" viewBox="0 0 24 24">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span class="popover-brand">Buffer Authenticator</span>
          <span class="popover-domain" id="domain-label"></span>
        </div>
        <div class="popover-actions-row">
          <button type="button" class="btn-popover-lock hidden" id="btn-popover-lock" title="Lock Vault">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </button>
          <button type="button" class="btn-close-popover" id="btn-close" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="accounts-list" id="accounts-list-container">
        <!-- Rendered dynamically -->
      </div>
    </div>
  `,document.body.appendChild(n);const s=l.getElementById("badge-trigger"),g=l.getElementById("popover-panel"),C=l.getElementById("domain-label"),p=l.getElementById("accounts-list-container"),k=l.getElementById("btn-close"),M=l.getElementById("btn-popover-lock");C.textContent=window.location.hostname;let h=[],b=null,m=!1,x=!1,B=!0;function L(){if(!document.contains(e)){n.remove();return}const o=e.getBoundingClientRect(),t=window.getComputedStyle(e);if(o.width===0||o.height===0||t.display==="none"||t.visibility==="hidden"){s.style.display="none",m&&E();return}s.style.display="flex";const i=24,u=Math.round(o.top+(o.height-i)/2),c=Math.round(o.right-i-6);s.style.top=`${u}px`,s.style.left=`${c}px`,m&&w(o)}function w(o){const t=o||e.getBoundingClientRect(),i=320,u=g.offsetHeight||160,c=Math.max(8,Math.min(t.left,window.innerWidth-i-12));window.innerHeight-t.bottom>=u+10||t.top<u+10?g.style.top=`${Math.round(t.bottom+6)}px`:g.style.top=`${Math.round(t.top-u-6)}px`,g.style.left=`${Math.round(c)}px`}function P(){b&&clearInterval(b),!(x||!B||h.length===0)&&(b=setInterval(async()=>{let o=!1;h.forEach(t=>{t.secondsRemaining-=1,t.secondsRemaining<=0&&(o=!0)}),o?(await T(),A()):V()},1e3))}function A(){if(p.innerHTML="",!B){M.classList.add("hidden"),p.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <p>Vault is not set up</p>
          <p class="empty-sub">Open Buffer Authenticator from your toolbar to set up your master password.</p>
        </div>
      `;return}if(x){M.classList.add("hidden"),p.innerHTML=`
        <div class="unlock-panel">
          <div class="unlock-header">
            <div class="unlock-icon-badge">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              </svg>
            </div>
            <div class="unlock-text">
              <div class="unlock-title">Vault is Locked</div>
              <div class="unlock-desc">Enter password to unlock 2FA codes</div>
            </div>
          </div>

          <form id="popover-unlock-form" class="unlock-form">
            <div class="unlock-input-row">
              <input
                type="password"
                id="popover-password-input"
                class="unlock-password-input"
                placeholder="Enter master password"
                autocomplete="current-password"
                required
              />
              <button type="button" id="popover-btn-toggle-eye" class="btn-toggle-eye" title="Show/Hide password">
                <svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
              </button>
            </div>

            <div id="popover-unlock-error" class="unlock-error-msg hidden"></div>

            <button type="submit" id="popover-btn-unlock" class="btn-unlock-action">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            </button>
          </form>
        </div>
      `;const o=p.querySelector("#popover-btn-toggle-eye"),t=p.querySelector("#popover-password-input"),i=p.querySelector("#popover-unlock-error"),u=p.querySelector("#popover-unlock-form"),c=p.querySelector("#popover-btn-unlock");let f=!1;o&&t&&o.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),f=!f,t.type=f?"text":"password",o.innerHTML=f?`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>`:`<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>`}),t&&(t.addEventListener("keydown",d=>d.stopPropagation()),t.addEventListener("keyup",d=>d.stopPropagation()),t.addEventListener("keypress",d=>d.stopPropagation()),setTimeout(()=>{m&&x&&t.focus()},50)),u&&t&&i&&c&&u.addEventListener("submit",async d=>{d.preventDefault(),d.stopPropagation();const v=t.value;if(v){i.classList.add("hidden"),i.textContent="",c.disabled=!0,c.innerHTML=`
            <svg class="spin-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25"/>
              <path d="M12 2a10 10 0 0 1 10 10"/>
            </svg>
            <span>Unlocking...</span>
          `;try{const y=await chrome.runtime.sendMessage({type:"UNLOCK_VAULT",payload:{password:v}});y&&y.success?(x=!1,await T(),A(),w(),P()):(c.disabled=!1,c.innerHTML=`
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
                </svg>
                <span>Unlock Vault</span>
              `,i.textContent=y?.error||"Incorrect master password",i.classList.remove("hidden"),t.focus(),t.select(),w())}catch(y){c.disabled=!1,c.innerHTML=`
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
              </svg>
              <span>Unlock Vault</span>
            `,i.textContent=y?.message||"Failed to unlock vault",i.classList.remove("hidden"),t.focus(),w()}}});return}if(M.classList.remove("hidden"),h.length===0){p.innerHTML=`
        <div class="empty-box">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <p>No 2FA account found for <strong>${N(window.location.hostname)}</strong></p>
          <p class="empty-sub">Add this account in Buffer Authenticator popup</p>
        </div>
      `;return}h.forEach(o=>{const t=document.createElement("div");t.className="account-card",t.setAttribute("data-id",o.id);const i=U(o.issuer||o.account),u=o.period||30,c=Math.max(0,o.secondsRemaining),f=Math.max(0,Math.min(100,c/u*100));let d="";c<=5?d="danger":c<=10&&(d="warning"),t.innerHTML=`
        <div class="card-top">
          <div class="card-avatar" style="background: ${i.bg}; color: ${i.color};">
            ${i.label}
          </div>
          <div class="card-info">
            <span class="card-issuer" title="${o.issuer||"Account"}">${o.issuer||"Account"}</span>
            <span class="card-account" title="${o.account}">${o.account}</span>
          </div>
        </div>

        <div class="card-middle">
          <span class="card-code" data-code="${o.code}">${F(o.code)}</span>
          <button type="button" class="btn-fill-action" data-fill="${o.code}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span>Fill Code</span>
          </button>
        </div>

        <div class="card-timer-row">
          <div class="timer-track">
            <div class="timer-fill ${d}" style="width: ${f}%;"></div>
          </div>
          <span class="timer-label">${c}s</span>
        </div>
      `;const v=t.querySelector(".btn-fill-action"),y=z=>{z.stopPropagation(),j(e,o.code),v.classList.add("filled"),v.innerHTML=`
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Filled!</span>
        `,setTimeout(()=>{E()},400)};v.addEventListener("click",y),t.addEventListener("click",z=>{z.target.closest(".btn-fill-action")||y(z)}),p.appendChild(t)})}function V(){h.forEach(o=>{const t=p.querySelector(`.account-card[data-id="${o.id}"]`);if(!t)return;const i=o.period||30,u=Math.max(0,o.secondsRemaining),c=Math.max(0,Math.min(100,u/i*100)),f=t.querySelector(".timer-fill"),d=t.querySelector(".timer-label"),v=t.querySelector(".card-code");f&&(f.style.width=`${c}%`,f.className="timer-fill",u<=5?f.classList.add("danger"):u<=10&&f.classList.add("warning")),d&&(d.textContent=`${u}s`),v&&(v.textContent=F(o.code))})}async function T(){try{const o={type:"GET_CODE_FOR_DOMAIN",payload:{domain:window.location.hostname}},t=await chrome.runtime.sendMessage(o);if(t&&t.success&&t.data)return x=!!t.data.isLocked,B=t.data.isInitialized!==!1,t.data.matched&&t.data.matched.length>0?h=t.data.matched:t.data.all&&t.data.all.length>0?h=t.data.all:h=[],!0;try{const i=await chrome.runtime.sendMessage({type:"GET_STATUS"});i&&i.success&&i.data&&(x=!!i.data.isLocked,B=!!i.data.isInitialized)}catch{x=!1}return h=[],!1}catch{return h=[],x=!1,!1}}async function q(){m=!0,s.classList.add("active"),p.innerHTML=`
      <div class="empty-box">
        <p>Loading live 2FA code...</p>
      </div>
    `,g.classList.add("open"),w(),await T(),A(),w(),P()}function E(){m=!1,s.classList.remove("active"),g.classList.remove("open"),b&&(clearInterval(b),b=null)}s.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),m?E():q()}),k.addEventListener("click",o=>{o.stopPropagation(),E()}),M.addEventListener("click",async o=>{o.stopPropagation();try{await chrome.runtime.sendMessage({type:"LOCK_VAULT"})}catch{}x=!0,h=[],b&&(clearInterval(b),b=null),A(),w()}),g.addEventListener("click",o=>{o.stopPropagation()}),document.addEventListener("click",o=>{if(!m)return;const t=o.target;t!==e&&!n.contains(t)&&E()}),document.addEventListener("keydown",o=>{o.key==="Escape"&&m&&E()}),window.addEventListener("scroll",L,{passive:!0,capture:!0}),window.addEventListener("resize",L,{passive:!0}),new ResizeObserver(()=>{L()}).observe(e),e.addEventListener("focus",L),e.addEventListener("input",L),L()}const D='input[autocomplete="one-time-code"], input[name*="otp" i], input[name*="2fa" i], input[name*="mfa" i], input[name*="code" i], input[id*="otp" i], input[id*="2fa" i], input[id*="code" i], input[placeholder*="code" i], input[type="tel"], input[type="number"]';function $(e=document){if(e.querySelectorAll(D).forEach(r=>{S(r)&&I(r)}),e===document){const r=document.querySelectorAll("input");r.length<60&&r.forEach(n=>{S(n)&&I(n)})}}$();const O=new MutationObserver(e=>{for(let a=0;a<e.length;a++){const r=e[a].addedNodes;for(let n=0;n<r.length;n++){const l=r[n];if(l.nodeType===1){const s=l;s.tagName==="INPUT"&&S(s)?I(s):s.firstElementChild&&$(s)}}}});function H(){const e=document.body||document.documentElement;e&&O.observe(e,{childList:!0,subtree:!0})}H();document.addEventListener("visibilitychange",()=>{document.hidden?O.disconnect():($(),H())});
